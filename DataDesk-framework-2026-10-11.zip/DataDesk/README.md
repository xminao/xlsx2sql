# DataDesk 开发框架

基于 [datadesk.md](datadesk.md) 和 [HTML Demo](datadesk-demo.html) 搭建的可运行前后端框架。

## 目录

```text
frontend/             Vue 3 + TypeScript + Vite + Element Plus
backend/app/main.py   FastAPI 控制面 API
backend/app/models.py SQLAlchemy 元数据与任务模型
backend/app/worker.py 独立的 Pull/Claim 导出 Worker
backend/exports/      Worker 生成的 CSV.GZ 文件（运行时创建）
```

## 本地启动（Windows PowerShell）

需 Python 3.11+、Node.js 20+。

```powershell
cd backend
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
uvicorn app.main:app --reload
```

另开一个终端启动 Worker：

```powershell
cd backend
.\.venv\Scripts\Activate.ps1
python -m app.worker
```

再开一个终端启动前端：

```powershell
cd frontend
npm install
npm run dev
```

浏览器访问 `http://127.0.0.1:5173`；API 文档在 `http://127.0.0.1:8000/docs`。

## 打包交付

先在 `frontend` 执行 `npm run build`，再从仓库根目录执行 `python scripts/package_release.py`。生成的 ZIP 包含前后端源码、构建后的页面、设计文档、`AGENTS.md`、`progress.md` 和 SHA-256 清单；不包含本地数据库、导出文件、依赖目录或密钥。解压后按上方步骤安装 Python 依赖即可由 FastAPI 托管构建页面。

API 运行时可在 `backend` 目录执行 `python smoke_test.py`，验证 Schema 校验、预览、任务认领、Worker 文件生成、下载与模拟重推。运行前暂停独立 Worker，避免它提前认领测试任务。

## 数据与接口

- 默认使用 `backend/datadesk.db`（SQLite），首次启动自动建表并写入示例报表、Schema 和供数记录。可设置 `DATABASE_URL=postgresql+psycopg://user:password@host:5432/datadesk` 改用 PostgreSQL。
- 自助取数表单由 `export_schemas.filter_config` 和 `columns_config` 生成，支持日期、单选、多选、数字范围、文本筛选。
- 预览调用 `/api/v1/exports/preview`，导出调用 `/api/v1/exports/create`。Worker 轮询 `/claim`，读取同一套 Schema 与 DSL，流式生成 CSV.GZ 后回报 `/complete`。下载中心轮询 `/my-tasks`。
- 后端统一校验主题、字段白名单、必填筛选、日期跨度、选项和导出上限；受限字段不可导出。任务保存提交时的筛选与上限快照。
- 供数监控支持查看失败记录及模拟重推；重推会创建新的运行记录。
- 外部供数 Job 可通过 `/api/v1/provision/jobs/start` 与 `/finish` 上报生命周期；成功回报若为零行会转成失败记录，报文样本最多保留 2 KB。
- `npm run build` 后重新启动 FastAPI，可由 FastAPI 托管 `frontend/dist`，访问 `http://127.0.0.1:8000`。

## 当前边界

默认 Schema 使用 `demo` 数据源。接入真实 PostgreSQL 数仓时，为 API 和 Worker 都设置 `WAREHOUSE_URL=postgresql://readonly:***@host:5432/warehouse`，再将目标 Schema 的 `source_kind` 改为 `postgres`、`source_table` 改为审核过的只读视图名（如 `mart.mall_sales_di`）。可在 `columns_config` / `filter_config` 为字段指定可选的 `source_field`，映射显示字段与实际列名。数仓账号必须只读；查询采用绑定参数、服务端游标和 5 分钟超时。配置说明见 [AGENTS.md](AGENTS.md) 与 [progress.md](progress.md)。

Power BI 链接、真实商场推送和身份鉴权尚未接入。供数重推目前是模拟执行。生产部署还需正式迁移管理、认证授权、任务租约/超时恢复、文件清理与审计等能力。

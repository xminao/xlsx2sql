"""Create a source + built UI archive without local runtime data."""

from datetime import date
from hashlib import sha256
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile


ROOT = Path(__file__).resolve().parents[1]
OUTPUT = ROOT / f"DataDesk-framework-{date.today().isoformat()}.zip"

FILES = [
    ".gitignore", "README.md", "AGENTS.md", "progress.md", "datadesk.md",
    "datadesk-demo.html", "frontend/index.html", "frontend/package.json",
    "frontend/package-lock.json", "frontend/tsconfig.json", "frontend/vite.config.ts",
    "backend/requirements.txt", "backend/smoke_test.py",
]
DIRECTORIES = ["frontend/src", "frontend/dist", "backend/app", "backend/tests", "scripts"]


def included_files() -> list[Path]:
    paths = [ROOT / name for name in FILES]
    for directory in DIRECTORIES:
        base = ROOT / directory
        if not base.is_dir():
            raise FileNotFoundError(base)
        paths.extend(path for path in base.rglob("*") if path.is_file())
    result = []
    for path in paths:
        if not path.is_file():
            raise FileNotFoundError(path)
        if path.is_symlink() or "__pycache__" in path.parts or path.suffix == ".pyc":
            continue
        path.resolve().relative_to(ROOT)
        result.append(path)
    return sorted(set(result), key=lambda item: item.relative_to(ROOT).as_posix())


def main() -> None:
    paths = included_files()
    manifest = []
    with ZipFile(OUTPUT, "w", ZIP_DEFLATED, compresslevel=9) as archive:
        for path in paths:
            relative = path.relative_to(ROOT).as_posix()
            content = path.read_bytes()
            archive.writestr(f"DataDesk/{relative}", content)
            manifest.append(f"{sha256(content).hexdigest()}  {relative}")
        archive.writestr("DataDesk/MANIFEST.sha256", "\n".join(manifest) + "\n")
    with ZipFile(OUTPUT) as archive:
        if bad_file := archive.testzip():
            raise RuntimeError(f"压缩包校验失败：{bad_file}")
        print(f"Created {OUTPUT.name}: {len(paths)} files, {OUTPUT.stat().st_size:,} bytes")


if __name__ == "__main__":
    main()

# DataDesk agent 工作说明

## 项目目标

依据 `datadesk.md` 建设企业内部数据服务工作台。当前仓库是可运行的开发框架：Vue 3 + Element Plus 前端、FastAPI 控制面、独立 Pull/Claim Worker。开发前先读 `README.md` 和 `progress.md`，需要理解原始业务意图时再读 `datadesk.md`。

## 代码入口

- `frontend/src/pages/StudioPage.vue`：Schema 驱动的自助取数表单。
- `frontend/src/api.ts`、`frontend/src/types.ts`：前端 API 契约与类型。
- `backend/app/main.py`：FastAPI 路由、任务状态和供数日志。
- `backend/app/export_query.py`：取数 DSL 校验、演示数据与 PostgreSQL 只读查询适配。
- `backend/app/worker.py`：认领任务、分批读取、流式生成 CSV.GZ、回报结果。
- `backend/app/models.py`、`seed.py`：元数据模型与演示主题。

## 开发约定

1. FastAPI 是控制面。大批量查询与文件生成留在 Worker；预览最多 50 行。
2. 前端只提交 `template_code`、字段白名单、结构化筛选 DSL 和行数上限，不提交 SQL。
3. 预览和导出必须使用 `export_query.py` 的同一套校验与查询入口。新增筛选控件时同步更新前端渲染、后端校验和查询翻译。
4. SQL 表名与列名只能来自服务端 Schema，并通过标识符校验；值必须绑定参数。数仓连接使用只读账号、查询超时和服务端游标。
5. 演示数据源是开发回退路径，不代表真实数仓性能。不要把示例行数、模拟供数回报或静态受限字段标识描述为生产级权限控制。
6. 不提交数据库文件、导出产物、密钥或 `.env`。新增持久化字段时兼顾现有开发数据库；正式环境的迁移仍需单独管理。
7. 完成有意义的功能变更后更新 `progress.md`，写明已完成、验证方式、待接入条件。

## 验证

```powershell
cd backend
python -m unittest discover -s tests -v
python smoke_test.py  # 需要先启动 API，并暂停独立 Worker，避免同时认领测试任务

cd ../frontend
npm run build
```

前端本地运行 `npm run dev`；API 运行 `python -m uvicorn app.main:app --reload`；Worker 运行 `python -m app.worker`。端口冲突时为 Vite 指定其他端口，例如 `npm run dev -- --port 5174 --strictPort`。


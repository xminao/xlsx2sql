"""End-to-end demo check against a running API: python smoke_test.py"""

import gzip
import json
import os
from datetime import date, timedelta
from urllib.error import HTTPError
from urllib.request import Request, urlopen

from app.worker import process


BASE = os.getenv("DATADESK_API_URL", "http://127.0.0.1:8000").rstrip("/")


def call(path, body=None):
    data = json.dumps(body).encode() if body is not None else None
    request = Request(BASE + path, data=data, headers={"Content-Type": "application/json"})
    with urlopen(request, timeout=20) as response:
        if path.endswith("/download"):
            return response.read()
        return json.load(response)


def main():
    assert call("/api/v1/health")["status"] == "ok"
    assert len(call("/api/v1/reports")) >= 1
    schemas = call("/api/v1/export-schemas")
    assert len(schemas) >= 1
    schema = next(s for s in schemas if s["code"] == "mall_sales_di")
    yesterday = (date.today() - timedelta(days=1)).isoformat()
    request = {
        "template_code": schema["code"], "selected_columns": ["biz_date", "mall_name", "sales_amount"],
        "filters": [{"field": "biz_date", "op": "between", "val": [yesterday, yesterday]}],
        "limit": 1,
    }
    assert call("/api/v1/exports/preview", request)["rows"]
    traffic = {
        "template_code": "store_traffic_di", "selected_columns": ["region", "visitors"],
        "filters": [
            {"field": "biz_date", "op": "between", "val": [yesterday, yesterday]},
            {"field": "region", "op": "in", "val": ["华北"]},
        ], "limit": 10,
    }
    assert call("/api/v1/exports/preview", traffic)["rows"] == [{"region": "华北", "visitors": 3426}]
    try:
        call("/api/v1/exports/preview", {**request, "selected_columns": ["cost_amount"]})
    except HTTPError as exc:
        assert exc.code == 422
    else:
        raise AssertionError("restricted column was accepted")
    created = call("/api/v1/exports/create", request)
    assert created["status"] == "PENDING" and created["limit"] == 1
    for _ in range(10):
        claimed = call("/api/v1/exports/claim", {})["task"]
        assert claimed and claimed["status"] == "RUNNING"
        process(claimed)
        if claimed["id"] == created["id"]:
            break
    else:
        raise AssertionError("new task was not claimed")
    tasks = call("/api/v1/exports/my-tasks")
    completed = next(t for t in tasks if t["id"] == created["id"])
    assert completed["status"] == "SUCCESS" and completed["row_count"] == 1
    csv_data = gzip.decompress(call(completed["download_url"])).decode("utf-8-sig")
    assert "sales_amount" in csv_data and "北京朝阳万达广场" in csv_data
    logs = call("/api/v1/provision/logs")
    failed = next(log for log in logs if log["status"] == "FAILED")
    retry = call(f"/api/v1/provision/jobs/retry?run_id={failed['id']}", {})
    assert retry["status"] == "RUNNING"
    started = call("/api/v1/provision/jobs/start", {
        "mall_name": "测试商场", "mall_group": "演示", "job_name": "销售明细",
        "protocol": "HTTP API", "biz_date": yesterday,
    })
    finished = call("/api/v1/provision/jobs/finish", {
        "run_id": started["id"], "status": "SUCCESS", "rows_pushed": 0,
        "duration_ms": 100, "resp_body": "empty payload",
    })
    assert finished["status"] == "FAILED" and "零行" in finished["error_msg"]
    print("Smoke test passed: schemas, validation, preview, claim, worker, download, retry, zero-row guard")


if __name__ == "__main__":
    main()

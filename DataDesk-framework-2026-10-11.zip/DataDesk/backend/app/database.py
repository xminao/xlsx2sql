import os
from pathlib import Path

from sqlalchemy import create_engine, inspect
from sqlalchemy.orm import DeclarativeBase, sessionmaker


BACKEND_DIR = Path(__file__).resolve().parents[1]
DEFAULT_DB = f"sqlite:///{(BACKEND_DIR / 'datadesk.db').as_posix()}"
DATABASE_URL = os.getenv("DATABASE_URL", DEFAULT_DB)

engine = create_engine(
    DATABASE_URL,
    connect_args={"check_same_thread": False} if DATABASE_URL.startswith("sqlite") else {},
    pool_pre_ping=True,
)
SessionLocal = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)


class Base(DeclarativeBase):
    pass


def get_db():
    with SessionLocal() as session:
        yield session


def upgrade_dev_schema():
    """Add the new export metadata columns to existing development databases.

    Production deployments should use a reviewed migration rather than create_all.
    """
    additions = {
        "export_schemas": {
            "source_kind": "VARCHAR(20) NOT NULL DEFAULT 'demo'",
            "source_table": "VARCHAR(160)",
        },
        "export_tasks": {"row_limit": "INTEGER NOT NULL DEFAULT 50000"},
    }
    for table, columns in additions.items():
        present = {column["name"] for column in inspect(engine).get_columns(table)}
        with engine.begin() as connection:
            for name, definition in columns.items():
                if name not in present:
                    connection.exec_driver_sql(f"ALTER TABLE {table} ADD COLUMN {name} {definition}")


"""Schema validation and a shared read path for preview and export.

The demo adapter keeps the project runnable without a warehouse. The PostgreSQL
adapter reads from an allowlisted view with bound values and a server-side cursor.
"""

import os
import re
from datetime import date
from decimal import Decimal, InvalidOperation
from typing import Iterator, Mapping

from .sample_data import rows_for


IDENTIFIER = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")
OPERATORS = {
    "date_range": "between",
    "number_range": "between",
    "select": "eq",
    "select_multiple": "in",
    "text": "like",
}


def _identifier(value: str) -> str:
    if not IDENTIFIER.fullmatch(value):
        raise ValueError(f"非法数据源标识符：{value}")
    return value


def validate_export(schema: Mapping, selected: list[str], filters: list[dict], limit: int) -> None:
    """Validate the complete DSL against the selected schema before any query runs."""
    if schema.get("source_kind") not in {"demo", "postgres"}:
        raise ValueError("不支持的数据源类型")
    if schema.get("source_kind") == "postgres":
        table = schema.get("source_table") or ""
        if len(table.split(".")) not in {1, 2}:
            raise ValueError("数仓视图名称无效")
        for part in table.split("."):
            _identifier(part)
    columns = {item["field"]: item for item in schema["columns_config"]}
    if not selected or len(set(selected)) != len(selected):
        raise ValueError("请至少选择一个不重复的输出字段")
    for field in selected:
        if field not in columns or columns[field].get("restricted"):
            raise ValueError(f"输出字段无权限或不存在：{field}")
        _identifier(columns[field].get("source_field") or field)
    if limit < 1 or limit > schema["max_limit"]:
        raise ValueError(f"导出上限应在 1 到 {schema['max_limit']} 行之间")

    definitions = {item["field"]: item for item in schema["filter_config"]}
    seen: set[str] = set()
    for item in filters:
        field, op, value = item["field"], item["op"], item["val"]
        if field in seen or field not in definitions:
            raise ValueError(f"筛选字段重复或未授权：{field}")
        seen.add(field)
        config = definitions[field]
        kind = config["type"]
        if op != OPERATORS.get(kind):
            raise ValueError(f"筛选操作符无效：{field}")
        _identifier(config.get("source_field") or field)
        if kind in {"date_range", "number_range"}:
            if not isinstance(value, list) or len(value) != 2:
                raise ValueError(f"筛选范围无效：{field}")
            if kind == "date_range":
                try:
                    start, end = (date.fromisoformat(part) for part in value)
                except (TypeError, ValueError):
                    raise ValueError(f"日期格式无效：{field}") from None
                if start > end or (end - start).days > int(config.get("max_days", 31)):
                    raise ValueError(f"日期范围超出限制：{field}")
            else:
                try:
                    low, high = (Decimal(str(part)) for part in value)
                except InvalidOperation:
                    raise ValueError(f"数字范围无效：{field}") from None
                if not low.is_finite() or not high.is_finite() or low > high:
                    raise ValueError(f"数字范围无效：{field}")
        elif kind == "select":
            if not isinstance(value, str) or not value or (config.get("options") and value not in config["options"]):
                raise ValueError(f"选项无效：{field}")
        elif kind == "select_multiple":
            if not isinstance(value, list) or not value or not all(isinstance(part, str) for part in value):
                raise ValueError(f"选项无效：{field}")
            if config.get("options") and any(part not in config["options"] for part in value):
                raise ValueError(f"选项无效：{field}")
        elif kind == "text":
            if not isinstance(value, str) or not 1 <= len(value) <= 100:
                raise ValueError(f"文本筛选无效：{field}")
        else:
            raise ValueError(f"不支持的筛选控件：{kind}")
    for field, config in definitions.items():
        if config.get("required") and field not in seen:
            raise ValueError(f"缺少必填筛选：{config.get('label', field)}")


def _matches(row: dict, filters: list[dict], definitions: dict) -> bool:
    for item in filters:
        actual = row.get(item["field"])
        if actual is None:
            return False
        op, value = item["op"], item["val"]
        if op == "eq" and str(actual) != str(value):
            return False
        if op == "in" and str(actual) not in value:
            return False
        if op == "like" and str(value).casefold() not in str(actual).casefold():
            return False
        if op == "between":
            if definitions[item["field"]]["type"] == "date_range":
                if not value[0] <= str(actual) <= value[1]:
                    return False
            elif not Decimal(str(value[0])) <= Decimal(str(actual)) <= Decimal(str(value[1])):
                return False
    return True


def _postgres_rows(schema: Mapping, selected: list[str], filters: list[dict], limit: int, batch_size: int) -> Iterator[dict]:
    try:
        import psycopg
        from psycopg import sql
    except ImportError as exc:
        raise RuntimeError("PostgreSQL 适配需要安装 psycopg[binary]") from exc
    warehouse_url = os.getenv("WAREHOUSE_URL")
    if not warehouse_url:
        raise RuntimeError("未设置 WAREHOUSE_URL")
    columns = {item["field"]: item for item in schema["columns_config"]}
    filter_defs = {item["field"]: item for item in schema["filter_config"]}
    projection = sql.SQL(", ").join(
        sql.SQL("{} AS {}").format(
            sql.Identifier(_identifier(columns[field].get("source_field") or field)),
            sql.Identifier(_identifier(field)),
        ) for field in selected
    )
    source = sql.Identifier(*[_identifier(part) for part in schema["source_table"].split(".")])
    conditions, params = [], []
    for item in filters:
        column = sql.Identifier(_identifier(filter_defs[item["field"]].get("source_field") or item["field"]))
        if item["op"] == "between":
            conditions.append(sql.SQL("{} BETWEEN %s AND %s").format(column))
            params.extend(item["val"])
        elif item["op"] == "eq":
            conditions.append(sql.SQL("{} = %s").format(column))
            params.append(item["val"])
        elif item["op"] == "in":
            conditions.append(sql.SQL("{} = ANY(%s)").format(column))
            params.append(item["val"])
        else:
            conditions.append(sql.SQL("{} ILIKE %s").format(column))
            params.append(f"%{item['val']}%")
    statement = sql.SQL("SELECT {} FROM {} WHERE {} LIMIT %s").format(
        projection, source, sql.SQL(" AND ").join(conditions) if conditions else sql.SQL("TRUE")
    )
    params.append(limit)
    with psycopg.connect(warehouse_url) as connection:
        connection.execute("SET TRANSACTION READ ONLY")
        connection.execute("SET LOCAL statement_timeout = '300000ms'")
        with connection.cursor(name="datadesk_export") as cursor:
            cursor.execute(statement, params)
            while batch := cursor.fetchmany(batch_size):
                for values in batch:
                    yield dict(zip(selected, values))


def iter_export_rows(schema: Mapping, selected: list[str], filters: list[dict], limit: int, batch_size: int = 10000) -> Iterator[dict]:
    """Yield rows from the configured source; caller must close the generator."""
    validate_export(schema, selected, filters, limit)
    if schema["source_kind"] == "postgres":
        yield from _postgres_rows(schema, selected, filters, limit, batch_size)
    else:
        count = 0
        definitions = {item["field"]: item for item in schema["filter_config"]}
        for row in rows_for(schema["code"]):
            if _matches(row, filters, definitions):
                yield {field: row.get(field) for field in selected}
                count += 1
                if count >= limit:
                    break

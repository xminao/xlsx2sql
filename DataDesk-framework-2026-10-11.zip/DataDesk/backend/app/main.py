import asyncio
import os
from contextlib import asynccontextmanager
from datetime import date, datetime, timedelta
from pathlib import Path
from uuid import uuid4

from fastapi import BackgroundTasks, Depends, FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field
from sqlalchemy import select, update
from sqlalchemy.orm import Session

from .database import BACKEND_DIR, Base, SessionLocal, engine, get_db, upgrade_dev_schema
from .export_query import iter_export_rows, validate_export
from .models import ExportSchema, ExportTask, ProvisionLog, Report
from .seed import seed_data, utc_now


EXPORT_DIR = BACKEND_DIR / "exports"
EXPORT_DIR.mkdir(exist_ok=True)


@asynccontextmanager
async def lifespan(_app: FastAPI):
    Base.metadata.create_all(bind=engine)
    upgrade_dev_schema()
    with SessionLocal() as db:
        seed_data(db)
    yield


app = FastAPI(title="DataDesk API", version="0.1.0", lifespan=lifespan)
app.add_middleware(
    CORSMiddleware,
    allow_origins=os.getenv("CORS_ORIGINS", "http://localhost:5173,http://127.0.0.1:5173,http://localhost:5174,http://127.0.0.1:5174").split(","),
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


class Filter(BaseModel):
    field: str
    op: str
    val: str | list[str]


class ExportRequest(BaseModel):
    template_code: str
    selected_columns: list[str] = Field(min_length=1)
    filters: list[Filter]
    limit: int = Field(default=50000, ge=1, le=200000)


class CompleteRequest(BaseModel):
    status: str
    file_name: str | None = None
    row_count: int = Field(default=0, ge=0)
    file_size_bytes: int = Field(default=0, ge=0)
    error_msg: str | None = None


class ProvisionStartRequest(BaseModel):
    mall_name: str = Field(min_length=1, max_length=120)
    mall_group: str = Field(min_length=1, max_length=40)
    job_name: str = Field(min_length=1, max_length=120)
    protocol: str = Field(min_length=1, max_length=30)
    biz_date: date


class ProvisionFinishRequest(BaseModel):
    run_id: str
    status: str
    rows_pushed: int = Field(ge=0)
    duration_ms: int = Field(ge=0)
    req_payload_sample: str | None = None
    resp_body: str | None = None
    error_msg: str | None = None


def schema_dict(row: ExportSchema):
    return {
        "code": row.code, "name": row.name, "category": row.category,
        "description": row.description, "source_kind": row.source_kind,
        "source_table": row.source_table, "columns_config": row.columns_config,
        "filter_config": row.filter_config, "max_limit": row.max_limit,
        "is_active": row.is_active, "updated_at": row.updated_at,
    }


def task_dict(row: ExportTask):
    return {
        "id": row.id, "template_code": row.template_code, "status": row.status,
        "selected_columns": row.selected_columns, "filters": row.filters, "limit": row.row_limit,
        "row_count": row.row_count, "file_size_bytes": row.file_size_bytes,
        "error_msg": row.error_msg, "created_at": row.created_at,
        "started_at": row.started_at, "completed_at": row.completed_at,
        "expires_at": row.expires_at,
        "download_url": f"/api/v1/exports/{row.id}/download" if row.status == "SUCCESS" else None,
    }


def provision_dict(row: ProvisionLog):
    return {
        "id": row.id, "mall_name": row.mall_name, "mall_group": row.mall_group,
        "job_name": row.job_name, "protocol": row.protocol, "biz_date": row.biz_date,
        "status": row.status, "rows_pushed": row.rows_pushed,
        "duration_ms": row.duration_ms, "response_summary": row.response_summary,
        "req_payload_sample": row.req_payload_sample, "resp_body": row.resp_body,
        "error_msg": row.error_msg, "trigger_type": row.trigger_type,
        "started_at": row.started_at, "completed_at": row.completed_at,
    }


def validated_schema(db: Session, request: ExportRequest):
    schema = db.get(ExportSchema, request.template_code)
    if not schema or not schema.is_active:
        raise HTTPException(404, "数据主题不存在或已停用")
    try:
        validate_export(schema_dict(schema), request.selected_columns, [item.model_dump() for item in request.filters], request.limit)
    except ValueError as exc:
        raise HTTPException(422, str(exc)) from None
    return schema


@app.get("/api/v1/health")
def health():
    return {"status": "ok", "service": "DataDesk API"}


@app.get("/api/v1/overview")
def overview(db: Session = Depends(get_db)):
    logs = db.scalars(select(ProvisionLog).order_by(ProvisionLog.started_at.desc())).all()
    tasks = db.scalars(select(ExportTask).order_by(ExportTask.created_at.desc())).all()
    successful = sum(item.status == "SUCCESS" for item in logs)
    return {
        "planned": len(logs), "success": successful,
        "failed": sum(item.status == "FAILED" for item in logs),
        "success_rate": round(successful / len(logs) * 100, 1) if logs else 0,
        "rows_pushed": sum(item.rows_pushed for item in logs),
        "my_exports": len(tasks), "active_exports": sum(item.status in {"PENDING", "RUNNING"} for item in tasks),
        "recent_logs": [provision_dict(item) for item in logs[:4]],
    }


@app.get("/api/v1/reports")
def reports(category: str | None = None, search: str | None = None, db: Session = Depends(get_db)):
    statement = select(Report).where(Report.is_active.is_(True)).order_by(Report.id)
    if category and category != "全部":
        statement = statement.where(Report.category == category)
    if search:
        statement = statement.where(Report.title.ilike(f"%{search}%"))
    return [{"id": row.id, "title": row.title, "category": row.category,
             "description": row.description, "owner": row.owner,
             "updated_at": row.updated_at, "power_bi_url": row.power_bi_url} for row in db.scalars(statement)]


@app.get("/api/v1/export-schemas")
def export_schemas(db: Session = Depends(get_db)):
    return [schema_dict(row) for row in db.scalars(select(ExportSchema).where(ExportSchema.is_active.is_(True)).order_by(ExportSchema.code))]


@app.get("/api/v1/export-schemas/{code}")
def export_schema(code: str, db: Session = Depends(get_db)):
    row = db.get(ExportSchema, code)
    if not row or not row.is_active:
        raise HTTPException(404, "数据主题不存在")
    return schema_dict(row)


@app.post("/api/v1/exports/preview")
def preview_export(request: ExportRequest, db: Session = Depends(get_db)):
    schema = validated_schema(db, request)
    rows = iter_export_rows(schema_dict(schema), request.selected_columns, [item.model_dump() for item in request.filters], 50)
    try:
        result = list(rows)
    finally:
        rows.close()
    return {"columns": request.selected_columns, "rows": result, "sample": schema.source_kind == "demo"}


@app.post("/api/v1/exports/create", status_code=201)
def create_export(request: ExportRequest, db: Session = Depends(get_db)):
    validated_schema(db, request)
    now = utc_now()
    row = ExportTask(
        id=str(uuid4()), template_code=request.template_code, selected_columns=request.selected_columns,
        filters=[item.model_dump() for item in request.filters], row_limit=request.limit, status="PENDING",
        created_at=now, expires_at=now + timedelta(hours=72),
    )
    db.add(row)
    db.commit()
    return task_dict(row)


@app.post("/api/v1/exports/claim")
def claim_export(db: Session = Depends(get_db)):
    # Conditional UPDATE prevents duplicate claims. PostgreSQL additionally skips locked rows.
    statement = select(ExportTask).where(ExportTask.status == "PENDING").order_by(ExportTask.created_at)
    if engine.dialect.name == "postgresql":
        statement = statement.with_for_update(skip_locked=True)
    for row in db.scalars(statement.limit(10)):
        result = db.execute(update(ExportTask).where(ExportTask.id == row.id, ExportTask.status == "PENDING").values(status="RUNNING", started_at=utc_now()))
        if result.rowcount == 1:
            db.commit()
            db.refresh(row)
            return {"task": task_dict(row)}
        db.rollback()
    return {"task": None}


@app.post("/api/v1/exports/{task_id}/complete")
def complete_export(task_id: str, request: CompleteRequest, db: Session = Depends(get_db)):
    row = db.get(ExportTask, task_id)
    if not row:
        raise HTTPException(404, "任务不存在")
    if row.status != "RUNNING":
        raise HTTPException(409, "任务不处于运行中")
    if request.status not in {"SUCCESS", "FAILED"}:
        raise HTTPException(422, "终态只能是 SUCCESS 或 FAILED")
    if request.status == "SUCCESS":
        if not request.file_name or Path(request.file_name).name != request.file_name or not (EXPORT_DIR / request.file_name).is_file():
            raise HTTPException(422, "文件不存在或文件名无效")
        row.file_name = request.file_name
        row.file_size_bytes = (EXPORT_DIR / request.file_name).stat().st_size
        row.row_count = request.row_count
    else:
        row.error_msg = request.error_msg or "Worker 执行失败"
    row.status = request.status
    row.completed_at = utc_now()
    db.commit()
    return {"acknowledged": True}


@app.get("/api/v1/exports/my-tasks")
def my_tasks(status: str | None = None, db: Session = Depends(get_db)):
    statement = select(ExportTask).order_by(ExportTask.created_at.desc())
    if status:
        statement = statement.where(ExportTask.status == status)
    return [task_dict(row) for row in db.scalars(statement.limit(100))]


@app.get("/api/v1/exports/{task_id}/download")
def download_export(task_id: str, db: Session = Depends(get_db)):
    row = db.get(ExportTask, task_id)
    if not row or row.status != "SUCCESS" or not row.file_name:
        raise HTTPException(404, "文件尚不可下载")
    if row.expires_at < utc_now():
        raise HTTPException(410, "文件已过期")
    file_path = EXPORT_DIR / row.file_name
    if not file_path.is_file():
        raise HTTPException(404, "文件不存在")
    return FileResponse(file_path, media_type="application/gzip", filename=row.file_name)


@app.get("/api/v1/provision/logs")
def provision_logs(status: str | None = None, search: str | None = None, db: Session = Depends(get_db)):
    statement = select(ProvisionLog).order_by(ProvisionLog.started_at.desc())
    if status:
        statement = statement.where(ProvisionLog.status == status)
    if search:
        statement = statement.where(ProvisionLog.mall_name.ilike(f"%{search}%"))
    return [provision_dict(row) for row in db.scalars(statement.limit(100))]


@app.get("/api/v1/provision/logs/{run_id}")
def provision_log(run_id: str, db: Session = Depends(get_db)):
    row = db.get(ProvisionLog, run_id)
    if not row:
        raise HTTPException(404, "运行记录不存在")
    return provision_dict(row)


@app.post("/api/v1/provision/jobs/start", status_code=201)
def start_provision(request: ProvisionStartRequest, db: Session = Depends(get_db)):
    row = ProvisionLog(
        id=str(uuid4()), mall_name=request.mall_name, mall_group=request.mall_group,
        job_name=request.job_name, protocol=request.protocol, biz_date=request.biz_date,
        status="RUNNING", rows_pushed=0, duration_ms=0, trigger_type="AUTO", started_at=utc_now(),
    )
    db.add(row)
    db.commit()
    return provision_dict(row)


@app.post("/api/v1/provision/jobs/finish")
def finish_provision(request: ProvisionFinishRequest, db: Session = Depends(get_db)):
    row = db.get(ProvisionLog, request.run_id)
    if not row:
        raise HTTPException(404, "运行记录不存在")
    if row.status != "RUNNING":
        raise HTTPException(409, "运行记录已结束")
    if request.status not in {"SUCCESS", "FAILED"}:
        raise HTTPException(422, "终态只能是 SUCCESS 或 FAILED")
    row.status = "FAILED" if request.status == "SUCCESS" and request.rows_pushed == 0 else request.status
    row.rows_pushed = request.rows_pushed if row.status == "SUCCESS" else 0
    row.duration_ms = request.duration_ms
    row.req_payload_sample = request.req_payload_sample[:2048] if request.req_payload_sample else None
    row.resp_body = request.resp_body[:2048] if request.resp_body else None
    row.response_summary = (request.resp_body or "200 OK · accepted")[:300]
    row.error_msg = "零行数据已拦截，禁止推送空包" if request.status == "SUCCESS" and request.rows_pushed == 0 else request.error_msg
    row.completed_at = utc_now()
    db.commit()
    return provision_dict(row)


async def finish_demo_retry(run_id: str):
    await asyncio.sleep(3)
    with SessionLocal() as db:
        row = db.get(ProvisionLog, run_id)
        if row and row.status == "RUNNING":
            row.status = "SUCCESS"
            row.rows_pushed = 6284
            row.duration_ms = 3000
            row.response_summary = "200 OK · demo retry accepted"
            row.completed_at = utc_now()
            db.commit()


@app.post("/api/v1/provision/jobs/retry", status_code=201)
def retry_provision(run_id: str, background: BackgroundTasks, db: Session = Depends(get_db)):
    original = db.get(ProvisionLog, run_id)
    if not original:
        raise HTTPException(404, "原始记录不存在")
    if original.status != "FAILED":
        raise HTTPException(409, "只能重推失败的任务")
    row = ProvisionLog(
        id=str(uuid4()), mall_name=original.mall_name, mall_group=original.mall_group,
        job_name=original.job_name, protocol=original.protocol, biz_date=original.biz_date,
        status="RUNNING", rows_pushed=0, duration_ms=0, trigger_type="MANUAL",
        triggered_by="demo-admin", started_at=utc_now(),
    )
    db.add(row)
    db.commit()
    background.add_task(finish_demo_retry, row.id)
    return provision_dict(row)


FRONTEND_DIST = BACKEND_DIR.parent / "frontend" / "dist"
if FRONTEND_DIST.is_dir():
    app.mount("/", StaticFiles(directory=FRONTEND_DIST, html=True), name="frontend")


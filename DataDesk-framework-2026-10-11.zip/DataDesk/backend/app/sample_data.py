from datetime import date, timedelta


def rows_for(code: str):
    yesterday = (date.today() - timedelta(days=1)).isoformat()
    day_before = (date.today() - timedelta(days=2)).isoformat()
    rows = {
        "mall_sales_di": [
            {"biz_date": yesterday, "mall_name": "北京朝阳万达广场", "store_name": "朝阳一店", "sales_amount": 35860.0, "order_count": 236},
            {"biz_date": yesterday, "mall_name": "上海五角场万达广场", "store_name": "五角场店", "sales_amount": 28540.0, "order_count": 192},
            {"biz_date": day_before, "mall_name": "成都龙湖时代天街", "store_name": "成都旗舰店", "sales_amount": 31220.0, "order_count": 208},
        ],
        "store_traffic_di": [
            {"biz_date": yesterday, "region": "华北", "store_name": "朝阳一店", "visitors": 3426, "conversion_rate": 0.069},
            {"biz_date": yesterday, "region": "华东", "store_name": "五角场店", "visitors": 2880, "conversion_rate": 0.067},
            {"biz_date": day_before, "region": "西南", "store_name": "成都旗舰店", "visitors": 3105, "conversion_rate": 0.072},
        ],
        "member_growth_di": [
            {"biz_date": yesterday, "channel": "小程序", "member_tier": "银卡", "new_members": 426, "active_members": 1850},
            {"biz_date": yesterday, "channel": "线下门店", "member_tier": "金卡", "new_members": 185, "active_members": 942},
            {"biz_date": day_before, "channel": "App", "member_tier": "银卡", "new_members": 312, "active_members": 1208},
        ],
        "inventory_snapshot": [
            {"biz_date": yesterday, "warehouse": "华东中心仓", "category": "服饰", "closing_stock": 12680, "turnover_days": 18},
            {"biz_date": yesterday, "warehouse": "华北中心仓", "category": "家居", "closing_stock": 8240, "turnover_days": 24},
            {"biz_date": day_before, "warehouse": "西南中心仓", "category": "美妆", "closing_stock": 6910, "turnover_days": 15},
        ],
    }
    return rows.get(code, [])


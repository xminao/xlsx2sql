"""Demo pull worker. Run separately: python -m app.worker"""

import csv
import gzip
import json
import logging
import os
import time
from contextlib import closing
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

from .database import BACKEND_DIR
from .export_query import iter_export_rows


API_BASE = os.getenv("DATADESK_API_URL", "http://127.0.0.1:8000").rstrip("/")
EXPORT_DIR = BACKEND_DIR / "exports"
EXPORT_DIR.mkdir(exist_ok=True)
logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")


def api_post(path: str, body: dict | None = None):
    payload = json.dumps(body or {}).encode("utf-8")
    request = Request(API_BASE + path, data=payload, headers={"Content-Type": "application/json"}, method="POST")
    with urlopen(request, timeout=20) as response:
        return json.load(response)


def api_get(path: str):
    with urlopen(API_BASE + path, timeout=20) as response:
        return json.load(response)


def process(task: dict):
    task_id = task["id"]
    selected = task["selected_columns"]
    file_name = f"{task_id}.csv.gz"
    file_path = EXPORT_DIR / file_name
    try:
        schema = api_get(f"/api/v1/export-schemas/{task['template_code']}")
        count = 0
        with gzip.open(file_path, "wt", encoding="utf-8-sig", newline="") as stream:
            writer = csv.writer(stream)
            writer.writerow(selected)
            with closing(iter_export_rows(schema, selected, task["filters"], task["limit"])) as rows:
                for row in rows:
                    writer.writerow([row.get(field, "") for field in selected])
                    count += 1
        api_post(f"/api/v1/exports/{task_id}/complete", {
            "status": "SUCCESS", "file_name": file_name, "row_count": count,
            "file_size_bytes": file_path.stat().st_size,
        })
        logging.info("Completed %s (%s rows)", task_id, count)
    except Exception as exc:
        file_path.unlink(missing_ok=True)
        logging.exception("Failed %s", task_id)
        api_post(f"/api/v1/exports/{task_id}/complete", {"status": "FAILED", "error_msg": str(exc)[:1000]})


def main():
    logging.info("DataDesk worker polling %s", API_BASE)
    while True:
        try:
            result = api_post("/api/v1/exports/claim")
            if result["task"]:
                process(result["task"])
            else:
                time.sleep(3)
        except (HTTPError, URLError, TimeoutError, OSError) as exc:
            logging.warning("API unavailable: %s", exc)
            time.sleep(5)


if __name__ == "__main__":
    main()


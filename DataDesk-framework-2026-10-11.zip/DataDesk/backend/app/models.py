from datetime import date, datetime

from sqlalchemy import BigInteger, Boolean, Date, DateTime, ForeignKey, Integer, JSON, String, Text
from sqlalchemy.orm import Mapped, mapped_column

from .database import Base


class Report(Base):
    __tablename__ = "reports"

    id: Mapped[int] = mapped_column(primary_key=True)
    title: Mapped[str] = mapped_column(String(120))
    category: Mapped[str] = mapped_column(String(40))
    description: Mapped[str] = mapped_column(Text)
    owner: Mapped[str] = mapped_column(String(80))
    updated_at: Mapped[datetime] = mapped_column(DateTime)
    power_bi_url: Mapped[str | None] = mapped_column(Text, nullable=True)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)


class ExportSchema(Base):
    __tablename__ = "export_schemas"

    code: Mapped[str] = mapped_column(String(80), primary_key=True)
    name: Mapped[str] = mapped_column(String(100))
    category: Mapped[str] = mapped_column(String(40))
    description: Mapped[str] = mapped_column(Text)
    source_kind: Mapped[str] = mapped_column(String(20), default="demo")
    source_table: Mapped[str | None] = mapped_column(String(160), nullable=True)
    columns_config: Mapped[list] = mapped_column(JSON)
    filter_config: Mapped[list] = mapped_column(JSON)
    max_limit: Mapped[int] = mapped_column(Integer, default=200000)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    updated_at: Mapped[datetime] = mapped_column(DateTime)


class ExportTask(Base):
    __tablename__ = "export_tasks"

    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    user_id: Mapped[str] = mapped_column(String(80), default="demo-admin")
    template_code: Mapped[str] = mapped_column(ForeignKey("export_schemas.code"))
    selected_columns: Mapped[list] = mapped_column(JSON)
    filters: Mapped[list] = mapped_column(JSON)
    row_limit: Mapped[int] = mapped_column(Integer, default=50000)
    status: Mapped[str] = mapped_column(String(16), default="PENDING", index=True)
    file_name: Mapped[str | None] = mapped_column(String(255), nullable=True)
    file_size_bytes: Mapped[int | None] = mapped_column(BigInteger, nullable=True)
    row_count: Mapped[int | None] = mapped_column(BigInteger, nullable=True)
    error_msg: Mapped[str | None] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime)
    started_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    completed_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    expires_at: Mapped[datetime] = mapped_column(DateTime)


class ProvisionLog(Base):
    __tablename__ = "provision_logs"

    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    mall_name: Mapped[str] = mapped_column(String(120))
    mall_group: Mapped[str] = mapped_column(String(40))
    job_name: Mapped[str] = mapped_column(String(120))
    protocol: Mapped[str] = mapped_column(String(30))
    biz_date: Mapped[date] = mapped_column(Date)
    status: Mapped[str] = mapped_column(String(16), index=True)
    rows_pushed: Mapped[int] = mapped_column(BigInteger, default=0)
    duration_ms: Mapped[int] = mapped_column(Integer, default=0)
    response_summary: Mapped[str | None] = mapped_column(Text, nullable=True)
    req_payload_sample: Mapped[str | None] = mapped_column(Text, nullable=True)
    resp_body: Mapped[str | None] = mapped_column(Text, nullable=True)
    error_msg: Mapped[str | None] = mapped_column(Text, nullable=True)
    trigger_type: Mapped[str] = mapped_column(String(16), default="AUTO")
    triggered_by: Mapped[str | None] = mapped_column(String(80), nullable=True)
    started_at: Mapped[datetime] = mapped_column(DateTime)
    completed_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)


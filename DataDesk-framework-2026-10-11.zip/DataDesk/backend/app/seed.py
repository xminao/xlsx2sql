from datetime import date, datetime, timedelta, timezone
from uuid import uuid4

from sqlalchemy import select
from sqlalchemy.orm import Session

from .models import ExportSchema, ProvisionLog, Report


def utc_now():
    return datetime.now(timezone.utc).replace(tzinfo=None)


def seed_data(db: Session):
    now = utc_now()
    if not db.scalar(select(Report.id).limit(1)):
        reports = [
            ("全国零售经营总览", "零售运营", "销售、客流、转化与门店达成情况的统一视图。", "零售运营部"),
            ("商场销售趋势分析", "零售运营", "多维对比商场经营趋势与日环比表现。", "商业分析组"),
            ("会员增长与留存", "用户增长", "跟踪拉新来源、会员活跃和留存漏斗。", "会员运营部"),
            ("库存健康度看板", "供应链", "监控库存结构、滞销风险及补货效率。", "供应链中心"),
            ("财务收入日报", "财务核算", "核对营业收入、退款和各渠道净收入。", "财务中心"),
            ("商场供数质量分析", "数据服务", "查看供数成功率、异常分布及恢复时间。", "数据平台组"),
        ]
        db.add_all(Report(title=a, category=b, description=c, owner=d, updated_at=now) for a, b, c, d in reports)

    if not db.scalar(select(ExportSchema.code).limit(1)):
        common_filters = [{"field": "biz_date", "label": "业务日期", "type": "date_range", "required": True, "max_days": 31}]
        extras = {
            "mall_sales_di": [{"field": "mall_name", "label": "商场", "type": "select", "required": False,
                               "options": ["北京朝阳万达广场", "上海五角场万达广场", "成都龙湖时代天街"]}],
            "store_traffic_di": [{"field": "region", "label": "区域", "type": "select_multiple", "required": False,
                                   "options": ["华北", "华东", "西南"]}],
            "member_growth_di": [{"field": "channel", "label": "渠道", "type": "select", "required": False,
                                   "options": ["小程序", "线下门店", "App"]}],
            "inventory_snapshot": [{"field": "warehouse", "label": "仓库", "type": "select", "required": False,
                                    "options": ["华东中心仓", "华北中心仓", "西南中心仓"]}],
        }
        specs = [
            ("mall_sales_di", "商场销售明细", "零售运营", "按商场、门店与日期查询销售流水和核心指标。", [
                ("biz_date", "业务日期"), ("mall_name", "商场名称"), ("store_name", "门店名称"),
                ("sales_amount", "销售额"), ("order_count", "订单量"), ("cost_amount", "成本金额")]),
            ("store_traffic_di", "门店客流分析", "零售运营", "分析进店客流、转化率及门店运营效率。", [
                ("biz_date", "业务日期"), ("region", "区域"), ("store_name", "门店名称"),
                ("visitors", "进店客流"), ("conversion_rate", "转化率")]),
            ("member_growth_di", "会员增长明细", "用户增长", "查看会员新增、活跃及渠道转化表现。", [
                ("biz_date", "业务日期"), ("channel", "渠道"), ("member_tier", "会员等级"),
                ("new_members", "新增会员"), ("active_members", "活跃会员")]),
            ("inventory_snapshot", "库存快照", "供应链", "按仓库与品类获取日末库存和周转数据。", [
                ("biz_date", "业务日期"), ("warehouse", "仓库"), ("category", "品类"),
                ("closing_stock", "期末库存"), ("turnover_days", "周转天数")]),
        ]
        for code, name, category, desc, columns in specs:
            db.add(ExportSchema(
                code=code, name=name, category=category, description=desc,
                source_kind="demo", source_table=None,
                columns_config=[{"field": field, "label": label, "default": field != "cost_amount",
                                 "restricted": field == "cost_amount"} for field, label in columns],
                filter_config=common_filters + extras[code], max_limit=200000, is_active=True, updated_at=now,
            ))

    # Upgrade only the original demo filter configuration. Keep custom schemas untouched.
    demo_extras = {
        "mall_sales_di": {"field": "mall_name", "label": "商场", "type": "select", "required": False,
                          "options": ["北京朝阳万达广场", "上海五角场万达广场", "成都龙湖时代天街"]},
        "store_traffic_di": {"field": "region", "label": "区域", "type": "select_multiple", "required": False,
                              "options": ["华北", "华东", "西南"]},
        "member_growth_di": {"field": "channel", "label": "渠道", "type": "select", "required": False,
                              "options": ["小程序", "线下门店", "App"]},
        "inventory_snapshot": {"field": "warehouse", "label": "仓库", "type": "select", "required": False,
                               "options": ["华东中心仓", "华北中心仓", "西南中心仓"]},
    }
    for schema in db.scalars(select(ExportSchema)):
        old = schema.filter_config
        if schema.source_kind == "demo" and schema.code in demo_extras and len(old) == 2 and old[0].get("field") == "biz_date" and "max_days" not in old[0] and old[1].get("field") == "mall_name":
            schema.filter_config = [{"field": "biz_date", "label": "业务日期", "type": "date_range", "required": True, "max_days": 31}, demo_extras[schema.code]]

    if not db.scalar(select(ProvisionLog.id).limit(1)):
        yesterday = date.today() - timedelta(days=1)
        rows = [
            ("北京朝阳万达广场", "万达", "每日销售明细", "HTTP API", "SUCCESS", 12864, 136000, None),
            ("上海五角场万达广场", "万达", "每日销售明细", "HTTP API", "SUCCESS", 9572, 108000, None),
            ("杭州万象城", "华润", "每日销售明细", "SFTP", "FAILED", 0, 32000, "SFTP authentication failed: credentials expired"),
            ("成都龙湖时代天街", "龙湖", "客流汇总", "HTTP API", "SUCCESS", 4812, 65000, None),
            ("深圳万象天地", "华润", "每日销售明细", "HTTP API", "FAILED", 0, 18000, "HTTP 401 Unauthorized: token expired"),
            ("重庆龙湖北城天街", "龙湖", "客流汇总", "HTTP API", "SUCCESS", 5328, 74000, None),
        ]
        db.add_all(ProvisionLog(
            id=str(uuid4()), mall_name=a, mall_group=b, job_name=c, protocol=d,
            biz_date=yesterday, status=e, rows_pushed=f, duration_ms=g,
            error_msg=h, response_summary=h or "200 OK · accepted", started_at=now-timedelta(minutes=i*7),
            completed_at=now-timedelta(minutes=i*7)+timedelta(milliseconds=g),
        ) for i, (a, b, c, d, e, f, g, h) in enumerate(rows))
    db.commit()


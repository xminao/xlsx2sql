import unittest
from datetime import date, timedelta

from app.export_query import iter_export_rows, validate_export


class ExportQueryTests(unittest.TestCase):
    def setUp(self):
        yesterday = date.today() - timedelta(days=1)
        self.day = yesterday.isoformat()
        self.schema = {
            "code": "mall_sales_di", "source_kind": "demo", "source_table": None,
            "max_limit": 200000,
            "columns_config": [
                {"field": "biz_date", "label": "业务日期"},
                {"field": "mall_name", "label": "商场"},
                {"field": "sales_amount", "label": "销售额"},
                {"field": "cost_amount", "label": "成本", "restricted": True},
            ],
            "filter_config": [
                {"field": "biz_date", "label": "业务日期", "type": "date_range", "required": True, "max_days": 31},
                {"field": "mall_name", "label": "商场", "type": "select", "required": False,
                 "options": ["北京朝阳万达广场", "上海五角场万达广场"]},
            ],
        }
        self.filters = [{"field": "biz_date", "op": "between", "val": [self.day, self.day]}]

    def test_demo_preview_and_limit_use_same_filter(self):
        filters = self.filters + [{"field": "mall_name", "op": "eq", "val": "北京朝阳万达广场"}]
        rows = list(iter_export_rows(self.schema, ["mall_name", "sales_amount"], filters, 1))
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0]["mall_name"], "北京朝阳万达广场")

    def test_rejects_restricted_column(self):
        with self.assertRaisesRegex(ValueError, "无权限"):
            validate_export(self.schema, ["cost_amount"], self.filters, 50)

    def test_rejects_missing_or_wide_date(self):
        with self.assertRaisesRegex(ValueError, "缺少必填"):
            validate_export(self.schema, ["biz_date"], [], 50)
        wide = [{"field": "biz_date", "op": "between", "val": ["2026-01-01", "2026-03-01"]}]
        with self.assertRaisesRegex(ValueError, "日期范围"):
            validate_export(self.schema, ["biz_date"], wide, 50)

    def test_rejects_unknown_filter_and_option(self):
        with self.assertRaisesRegex(ValueError, "未授权"):
            validate_export(self.schema, ["biz_date"], self.filters + [{"field": "secret", "op": "eq", "val": "x"}], 50)
        with self.assertRaisesRegex(ValueError, "选项无效"):
            validate_export(self.schema, ["biz_date"], self.filters + [{"field": "mall_name", "op": "eq", "val": "不存在"}], 50)

    def test_rejects_unsafe_source_identifier(self):
        self.schema["source_kind"] = "postgres"
        self.schema["source_table"] = "mart.sales;DROP TABLE users"
        with self.assertRaisesRegex(ValueError, "标识符"):
            validate_export(self.schema, ["biz_date"], self.filters, 50)

    def test_multiple_choice_and_number_range(self):
        schema = {
            "code": "store_traffic_di", "source_kind": "demo", "source_table": None,
            "max_limit": 100,
            "columns_config": [{"field": "region"}, {"field": "visitors"}],
            "filter_config": [
                {"field": "biz_date", "label": "业务日期", "type": "date_range", "required": True, "max_days": 31},
                {"field": "region", "label": "区域", "type": "select_multiple", "required": False, "options": ["华北", "华东", "西南"]},
                {"field": "visitors", "label": "进店客流", "type": "number_range", "required": False},
            ],
        }
        filters = self.filters + [
            {"field": "region", "op": "in", "val": ["华北", "西南"]},
            {"field": "visitors", "op": "between", "val": ["3000", "4000"]},
        ]
        rows = list(iter_export_rows(schema, ["region", "visitors"], filters, 10))
        self.assertEqual(rows, [{"region": "华北", "visitors": 3426}])


if __name__ == "__main__":
    unittest.main()

# DataDesk 开发进度

更新日期：2026-10-11

## 已完成

- [x] 单文件交互 Demo（`datadesk-demo.html`）。
- [x] Vue 3 + TypeScript + Element Plus 工作台：总览、报表、自助取数、下载中心、供数监控、数据资产。
- [x] FastAPI 元数据、报表、任务和供数日志接口；SQLite 开发数据库，支持 PostgreSQL 元数据连接。
- [x] 独立 Pull/Claim Worker、CSV.GZ 导出、任务状态回报与文件下载。
- [x] 自助取数表单按 Schema 渲染日期范围、单选、多选、数字范围和文本筛选。
- [x] 预览和 Worker 共用 `export_query.py`：白名单、必填项、日期跨度、行数上限与受限字段校验。
- [x] PostgreSQL 只读数仓适配器：参数绑定、服务端游标、分批读取和查询超时；保留演示数据源。
- [x] 导出上限写入任务快照，Worker 按快照执行；开发数据库自动补齐新增列。
- [x] 供数 Job `start/finish`、零行拦截、失败明细及模拟重推。
- [x] 提供 `scripts/package_release.py`，可打包源码、构建页面与文档并生成 SHA-256 清单。

## 已验证

- `python -m unittest discover -s tests -v`：DSL 权限、范围、字段、多选与数字区间检查通过。
- `npm run build`：Vue 类型检查与 Vite 构建通过。
- `python smoke_test.py`：在现有开发数据库自动补列后，API 预览、异步任务、Worker 文件、下载与供数状态链路通过。
- 浏览器检查 `http://127.0.0.1:5174/#/studio`：库存主题显示日期与仓库筛选、对应字段和演示数据源说明。

## 待接入

- [ ] 提供真实数仓只读连接 `WAREHOUSE_URL`，并将业务主题映射到已审核的表或视图。
- [ ] 接入身份认证、角色和行级权限；当前受限字段为静态演示规则。
- [ ] 配置真实 Power BI 报表地址与授权策略。
- [ ] 接入真实商场供数 SDK/Job、密钥托管和重推执行器。
- [ ] 加入正式数据库迁移、Worker 租约/超时恢复、72 小时文件清理和审计日志。


import { createRouter, createWebHashHistory } from 'vue-router'

export const pageNames: Record<string, string> = {
  '/': '总览', '/reports': '报表中心', '/studio': '自助取数',
  '/downloads': '下载中心', '/provision': '供数监控', '/assets': '数据资产',
}

export default createRouter({
  history: createWebHashHistory(),
  routes: [
    { path: '/', component: () => import('./pages/OverviewPage.vue') },
    { path: '/reports', component: () => import('./pages/ReportsPage.vue') },
    { path: '/studio', component: () => import('./pages/StudioPage.vue') },
    { path: '/downloads', component: () => import('./pages/DownloadsPage.vue') },
    { path: '/provision', component: () => import('./pages/ProvisionPage.vue') },
    { path: '/assets', component: () => import('./pages/AssetsPage.vue') },
  ],
})

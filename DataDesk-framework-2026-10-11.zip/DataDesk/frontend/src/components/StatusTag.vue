<script setup lang="ts">
import type { Status } from '../types'
defineProps<{ status: Status }>()
const labels: Record<Status, string> = { PENDING: '排队中', RUNNING: '运行中', SUCCESS: '成功', FAILED: '失败', CANCELLED: '已取消' }
</script>

<template><span class="status-tag" :class="status.toLowerCase()">{{ labels[status] }}</span></template>

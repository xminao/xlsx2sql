import type { ExportRequest, ExportSchema, ExportTask, Overview, ProvisionLog, Report } from './types'

const base = import.meta.env.VITE_API_BASE || '/api/v1'

async function request<T>(path: string, init?: RequestInit): Promise<T> {
  const response = await fetch(`${base}${path}`, {
    ...init,
    headers: { 'Content-Type': 'application/json', ...init?.headers },
  })
  if (!response.ok) {
    let message = `请求失败 (${response.status})`
    try {
      const body = await response.json()
      message = typeof body.detail === 'string' ? body.detail : message
    } catch { /* keep HTTP status */ }
    throw new Error(message)
  }
  return response.json() as Promise<T>
}

export const api = {
  overview: () => request<Overview>('/overview'),
  reports: () => request<Report[]>('/reports'),
  schemas: () => request<ExportSchema[]>('/export-schemas'),
  preview: (body: ExportRequest) => request<{ columns: string[]; rows: Record<string, unknown>[]; sample: boolean }>('/exports/preview', { method: 'POST', body: JSON.stringify(body) }),
  createExport: (body: ExportRequest) => request<ExportTask>('/exports/create', { method: 'POST', body: JSON.stringify(body) }),
  tasks: () => request<ExportTask[]>('/exports/my-tasks'),
  provisionLogs: () => request<ProvisionLog[]>('/provision/logs'),
  retryProvision: (runId: string) => request<ProvisionLog>(`/provision/jobs/retry?run_id=${encodeURIComponent(runId)}`, { method: 'POST' }),
  downloadUrl: (task: ExportTask) => `${base}/exports/${task.id}/download`,
}

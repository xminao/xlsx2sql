export type Status = 'PENDING' | 'RUNNING' | 'SUCCESS' | 'FAILED' | 'CANCELLED'
export interface Report {
  id: number; title: string; category: string; description: string; owner: string
  updated_at: string; power_bi_url: string | null
}
export interface ColumnConfig { field: string; label: string; default: boolean; restricted: boolean }
export interface FilterConfig { field: string; label: string; type: 'date_range' | 'select' | 'select_multiple' | 'number_range' | 'text'; required: boolean; options?: string[]; max_days?: number }
export interface ExportSchema {
  code: string; name: string; category: string; description: string
  source_kind: 'demo' | 'postgres'; source_table: string | null
  columns_config: ColumnConfig[]; filter_config: FilterConfig[]
  max_limit: number; is_active: boolean; updated_at: string
}
export interface Filter { field: string; op: string; val: string | string[] }
export interface ExportRequest { template_code: string; selected_columns: string[]; filters: Filter[]; limit: number }
export interface ExportTask {
  id: string; template_code: string; status: Status; selected_columns: string[]; filters: Filter[]
  limit: number
  row_count: number | null; file_size_bytes: number | null; error_msg: string | null
  created_at: string; started_at: string | null; completed_at: string | null
  expires_at: string; download_url: string | null
}
export interface ProvisionLog {
  id: string; mall_name: string; mall_group: string; job_name: string; protocol: string
  biz_date: string; status: Status; rows_pushed: number; duration_ms: number
  response_summary: string | null; req_payload_sample: string | null; resp_body: string | null
  error_msg: string | null; trigger_type: string
  started_at: string; completed_at: string | null
}
export interface Overview {
  planned: number; success: number; failed: number; success_rate: number; rows_pushed: number
  my_exports: number; active_exports: number; recent_logs: ProvisionLog[]
}

<script setup lang="ts">
import { computed, onMounted, ref, watch } from 'vue'
import { ElMessage } from 'element-plus'
import { useRoute, useRouter } from 'vue-router'
import { api } from '../api'
import PageHeader from '../components/PageHeader.vue'
import type { ExportRequest, ExportSchema, Filter, FilterConfig } from '../types'

const router = useRouter()
const route = useRoute()
const schemas = ref<ExportSchema[]>([])
const code = ref('')
const selectedColumns = ref<string[]>([])
const dates = ref<Record<string, string[]>>({})
const scalars = ref<Record<string, string>>({})
const multiples = ref<Record<string, string[]>>({})
const numberStarts = ref<Record<string, string>>({})
const numberEnds = ref<Record<string, string>>({})
const limit = ref(50000)
const preview = ref<Record<string, unknown>[]>([])
const previewColumns = ref<string[]>([])
const loadingPreview = ref(false)
const submitting = ref(false)
const current = computed(() => schemas.value.find(schema => schema.code === code.value))
const labels = computed(() => Object.fromEntries(current.value?.columns_config.map(column => [column.field, column.label]) || []))
const limitOptions = computed(() => [...new Set([50000, 100000, current.value?.max_limit || 50000])].filter(value => value <= (current.value?.max_limit || 50000)).sort((a, b) => a - b))

function isoDay(offset: number) {
  const value = new Date()
  value.setDate(value.getDate() + offset)
  return `${value.getFullYear()}-${String(value.getMonth() + 1).padStart(2, '0')}-${String(value.getDate()).padStart(2, '0')}`
}

function resetForm() {
  selectedColumns.value = current.value?.columns_config.filter(column => column.default && !column.restricted).map(column => column.field) || []
  dates.value = {}
  scalars.value = {}
  multiples.value = {}
  numberStarts.value = {}
  numberEnds.value = {}
  for (const filter of current.value?.filter_config || []) {
    if (filter.type === 'date_range') dates.value[filter.field] = [isoDay(-7), isoDay(-1)]
    if (filter.type === 'select_multiple') multiples.value[filter.field] = []
    if (filter.type === 'select' || filter.type === 'text') scalars.value[filter.field] = ''
    if (filter.type === 'number_range') { numberStarts.value[filter.field] = ''; numberEnds.value[filter.field] = '' }
  }
  limit.value = Math.min(50000, current.value?.max_limit || 50000)
  preview.value = []
  previewColumns.value = []
}

onMounted(async () => {
  try {
    schemas.value = await api.schemas()
    code.value = schemas.value.find(schema => schema.code === route.query.schema)?.code || schemas.value[0]?.code || ''
  } catch (error) { ElMessage.error((error as Error).message) }
})
watch(code, resetForm)
watch([selectedColumns, dates, scalars, multiples, numberStarts, numberEnds, limit], () => {
  preview.value = []
  previewColumns.value = []
}, { deep: true })

function makeFilter(config: FilterConfig): Filter | null {
  const field = config.field
  if (config.type === 'date_range') {
    const value = dates.value[field] || []
    if (value.length !== 2) return null
    const days = (new Date(value[1]).getTime() - new Date(value[0]).getTime()) / 86400000
    if (days < 0 || days > (config.max_days || 31)) throw new Error(`${config.label}范围最多 ${config.max_days || 31} 天`)
    return { field, op: 'between', val: value }
  }
  if (config.type === 'number_range') {
    const start = numberStarts.value[field], end = numberEnds.value[field]
    if (!start && !end) return null
    if (!start || !end || Number(start) > Number(end)) throw new Error(`${config.label}范围无效`)
    return { field, op: 'between', val: [start, end] }
  }
  if (config.type === 'select_multiple') {
    const value = multiples.value[field] || []
    return value.length ? { field, op: 'in', val: value } : null
  }
  const value = scalars.value[field]?.trim()
  return value ? { field, op: config.type === 'text' ? 'like' : 'eq', val: value } : null
}

function body(): ExportRequest | null {
  if (!current.value) { ElMessage.warning('请选择数据主题'); return null }
  if (!selectedColumns.value.length) { ElMessage.warning('请至少选择一个输出字段'); return null }
  try {
    const filters: Filter[] = []
    for (const config of current.value.filter_config) {
      const filter = makeFilter(config)
      if (!filter && config.required) throw new Error(`请填写${config.label}`)
      if (filter) filters.push(filter)
    }
    return { template_code: code.value, selected_columns: [...selectedColumns.value], filters, limit: limit.value }
  } catch (error) { ElMessage.warning((error as Error).message); return null }
}

async function loadPreview() {
  const request = body()
  if (!request) return
  loadingPreview.value = true
  try {
    const response = await api.preview(request)
    preview.value = response.rows
    previewColumns.value = response.columns
    ElMessage.success(response.sample ? '已加载演示数据预览' : '预览查询完成')
  } catch (error) { ElMessage.error((error as Error).message) }
  finally { loadingPreview.value = false }
}

async function submit() {
  const request = body()
  if (!request) return
  submitting.value = true
  try {
    await api.createExport(request)
    ElMessage.success('导出任务已提交，等待 Worker 认领')
    router.push('/downloads')
  } catch (error) { ElMessage.error((error as Error).message) }
  finally { submitting.value = false }
}
</script>

<template>
  <PageHeader eyebrow="SELF SERVICE EXPORT" title="自助取数" description="按主题配置筛选条件、预览数据并提交异步导出任务。">
    <el-button @click="router.push('/downloads')">我的下载任务</el-button>
  </PageHeader>
  <div class="studio-layout">
    <section class="form-panel">
      <div class="step-label"><b>1</b> 选择数据主题</div>
      <el-form label-position="top">
        <el-form-item label="业务主题">
          <el-select v-model="code" style="width:100%">
            <el-option v-for="schema in schemas" :key="schema.code" :label="`${schema.category} / ${schema.name}`" :value="schema.code" />
          </el-select>
          <small class="form-hint">{{ current?.description }}</small>
        </el-form-item>
        <el-divider />
        <div class="step-label"><b>2</b> 设置筛选条件</div>
        <div class="form-grid">
          <el-form-item v-for="filter in current?.filter_config || []" :key="filter.field" :label="`${filter.label}${filter.required ? '（必填）' : ''}`" :class="{ 'wide-filter': filter.type === 'date_range' }">
            <el-date-picker v-if="filter.type === 'date_range'" v-model="dates[filter.field]" type="daterange" value-format="YYYY-MM-DD" start-placeholder="开始日期" end-placeholder="结束日期" style="width:100%" />
            <el-select v-else-if="filter.type === 'select'" v-model="scalars[filter.field]" clearable placeholder="全部" style="width:100%">
              <el-option v-for="option in filter.options || []" :key="option" :label="option" :value="option" />
            </el-select>
            <el-select v-else-if="filter.type === 'select_multiple'" v-model="multiples[filter.field]" multiple collapse-tags clearable placeholder="全部" style="width:100%">
              <el-option v-for="option in filter.options || []" :key="option" :label="option" :value="option" />
            </el-select>
            <div v-else-if="filter.type === 'number_range'" class="number-range">
              <el-input v-model="numberStarts[filter.field]" type="number" placeholder="最小值" />
              <span>—</span>
              <el-input v-model="numberEnds[filter.field]" type="number" placeholder="最大值" />
            </div>
            <el-input v-else v-model="scalars[filter.field]" clearable :placeholder="`输入${filter.label}`" />
            <small v-if="filter.type === 'date_range'" class="form-hint">最多 {{ filter.max_days || 31 }} 天</small>
          </el-form-item>
          <el-form-item label="导出上限">
            <el-select v-model="limit" style="width:100%">
              <el-option v-for="option in limitOptions" :key="option" :value="option" :label="`最多 ${option.toLocaleString()} 行`" />
            </el-select>
          </el-form-item>
        </div>
        <el-divider />
        <div class="step-label"><b>3</b> 选择输出字段</div>
        <el-checkbox-group v-model="selectedColumns" class="column-grid">
          <el-checkbox v-for="column in current?.columns_config || []" :key="column.field" :value="column.field" :disabled="column.restricted" border>{{ column.label }}{{ column.restricted ? ' 🔒' : '' }}</el-checkbox>
        </el-checkbox-group>
        <p class="help-text">受限字段由 API 再次校验。数据权限与身份系统尚待接入。</p>
        <div class="form-actions"><el-button :loading="loadingPreview" @click="loadPreview">查询预览</el-button><el-button type="primary" :loading="submitting" @click="submit">提交导出任务</el-button></div>
      </el-form>
    </section>
    <aside>
      <section class="side-panel">
        <h2>数据预览</h2><small>最多展示 50 行</small>
        <div v-if="preview.length" class="preview-scroll"><el-table :data="preview" border size="small"><el-table-column v-for="field in previewColumns" :key="field" :prop="field" :label="labels[field] || field" min-width="110" /></el-table></div>
        <el-empty v-else description="完成筛选条件后点击查询预览" :image-size="70" />
        <div class="notice">{{ current?.source_kind === 'demo' ? '当前主题使用演示数据。' : '当前主题连接只读数仓。' }}导出由独立 Worker 异步处理，文件保留 72 小时。</div>
      </section>
      <section class="side-panel schema-info"><h2>当前主题信息</h2><div><span>Schema 编码</span><strong>{{ current?.code || '—' }}</strong></div><div><span>数据源</span><strong>{{ current?.source_kind === 'postgres' ? 'PostgreSQL 只读视图' : '演示数据' }}</strong></div><div><span>可用字段</span><strong>{{ current?.columns_config.length || 0 }} 个</strong></div><div><span>处理方式</span><strong>异步排队 · CSV.GZ</strong></div></section>
    </aside>
  </div>
</template>

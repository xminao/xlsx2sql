<script setup lang="ts">
import { computed, onMounted, ref } from 'vue'
import { ElMessage } from 'element-plus'
import { api } from '../api'
import PageHeader from '../components/PageHeader.vue'
import type { Report } from '../types'

const reports = ref<Report[]>([])
const category = ref('全部')
const query = ref('')
const selected = ref<Report | null>(null)
const favorites = ref<number[]>(JSON.parse(localStorage.getItem('datadesk-favorites') || '[]'))
const categories = ['全部', '零售运营', '用户增长', '供应链', '财务核算', '数据服务', '我的收藏']
const filtered = computed(() => reports.value.filter(r => (category.value === '全部' || category.value === '我的收藏' && favorites.value.includes(r.id) || r.category === category.value) && `${r.title}${r.description}${r.owner}`.includes(query.value)))
onMounted(async () => { try { reports.value = await api.reports() } catch (e) { ElMessage.error((e as Error).message) } })
function toggleFavorite(id: number) { favorites.value = favorites.value.includes(id) ? favorites.value.filter(x => x !== id) : [...favorites.value, id]; localStorage.setItem('datadesk-favorites', JSON.stringify(favorites.value)) }
function openReport() { if (selected.value?.power_bi_url) window.open(selected.value.power_bi_url, '_blank', 'noopener,noreferrer'); else ElMessage.info('请在后台配置 Power BI 报表地址后使用此功能') }
</script>

<template>
  <PageHeader eyebrow="REPORT LIBRARY" title="报表中心" description="集中查看经授权的业务报表。点击卡片可预览报表信息。"><span class="soft-badge">{{ reports.length }} 份报表</span></PageHeader>
  <div class="filter-bar"><el-tabs v-model="category" class="report-tabs"><el-tab-pane v-for="item in categories" :key="item" :label="item" :name="item" /></el-tabs><el-input v-model="query" clearable placeholder="搜索报表名称或部门" style="width:230px" /></div>
  <div v-if="filtered.length" class="report-grid"><div v-for="(report, index) in filtered" :key="report.id" class="report-card"><div class="report-cover" :class="`cover-${index % 6}`"><span>{{ report.category }}</span><div class="cover-rings" /></div><div class="report-details"><div class="flex-between"><h3>{{ report.title }}</h3><button class="favorite" :class="{ on: favorites.includes(report.id) }" :aria-label="favorites.includes(report.id) ? '取消收藏' : '收藏报表'" @click="toggleFavorite(report.id)">{{ favorites.includes(report.id) ? '★' : '☆' }}</button></div><p>{{ report.description }}</p><div class="report-footer"><small>{{ report.owner }} · {{ new Date(report.updated_at + 'Z').toLocaleDateString('zh-CN') }} 更新</small><el-button size="small" type="primary" plain @click="selected = report">查看报表 →</el-button></div></div></div></div>
  <el-empty v-else description="没有找到匹配的报表" />
  <el-dialog :model-value="!!selected" :title="selected?.title || ''" width="min(580px, 95vw)" @update:model-value="(value: boolean) => { if (!value) selected = null }"><div class="report-placeholder"><div v-for="height in [36,55,43,68,61,78,70,91,74,85,95,81]" :key="height" :style="{ height: `${height}%` }" /></div><el-descriptions :column="1" border class="mt-18"><el-descriptions-item label="业务分类">{{ selected?.category }}</el-descriptions-item><el-descriptions-item label="维护部门">{{ selected?.owner }}</el-descriptions-item><el-descriptions-item label="报表说明">{{ selected?.description }}</el-descriptions-item></el-descriptions><p class="help-text">图形为界面占位预览，正式报表由 Power BI 提供。</p><template #footer><el-button @click="selected = null">关闭</el-button><el-button type="primary" @click="openReport">打开 Power BI 报表</el-button></template></el-dialog>
</template>

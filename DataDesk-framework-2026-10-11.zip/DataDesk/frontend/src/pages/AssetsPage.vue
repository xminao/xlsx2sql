<script setup lang="ts">
import { onMounted, ref } from 'vue'
import { ElMessage } from 'element-plus'
import { useRouter } from 'vue-router'
import { api } from '../api'
import PageHeader from '../components/PageHeader.vue'
import type { ExportSchema } from '../types'

const router = useRouter()
const schemas = ref<ExportSchema[]>([])
onMounted(async () => { try { schemas.value = await api.schemas() } catch (e) { ElMessage.error((e as Error).message) } })
</script>

<template>
  <PageHeader eyebrow="DATA ASSETS" title="数据资产" description="通过元数据定义取数主题、可选字段和安全边界。"><span class="soft-badge">{{ schemas.length }} 个已启用 Schema</span></PageHeader>
  <div class="asset-grid"><div v-for="schema in schemas" :key="schema.code" class="asset-card"><div class="flex-between"><h3>{{ schema.name }}</h3><span class="status-tag success">已启用</span></div><p>{{ schema.description }}</p><div class="asset-tags"><span>{{ schema.category }}</span><span>{{ schema.columns_config.length }} 个字段</span><span>日期必填</span><span>最高 {{ (schema.max_limit / 10000).toFixed(0) }} 万行</span></div><div class="asset-footer"><small>{{ schema.code }}</small><el-button link type="primary" @click="router.push({ path: '/studio', query: { schema: schema.code } })">用此主题取数 →</el-button></div></div></div>
  <div class="notice mt-18">切换主题后，字段清单和筛选器来自后端 Schema 配置。受限字段在界面禁用，API 也会校验字段白名单。</div>
</template>

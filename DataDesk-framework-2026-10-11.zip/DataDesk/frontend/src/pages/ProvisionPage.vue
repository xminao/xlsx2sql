<script setup lang="ts">
import { computed, onMounted, onUnmounted, ref } from 'vue'
import { ElMessage } from 'element-plus'
import { api } from '../api'
import PageHeader from '../components/PageHeader.vue'
import StatusTag from '../components/StatusTag.vue'
import type { ProvisionLog } from '../types'

const logs = ref<ProvisionLog[]>([])
const query = ref('')
const status = ref('')
const selected = ref<ProvisionLog | null>(null)
const retrying = ref(false)
const filtered = computed(() => logs.value.filter(x => (!status.value || x.status === status.value) && `${x.mall_name}${x.job_name}${x.mall_group}`.includes(query.value)))
let timer: ReturnType<typeof setInterval> | undefined
async function refresh() { try { logs.value = await api.provisionLogs(); if (selected.value) selected.value = logs.value.find(x => x.id === selected.value?.id) || selected.value } catch (e) { ElMessage.error((e as Error).message) } }
onMounted(() => { refresh(); timer = setInterval(refresh, 5000) })
onUnmounted(() => { if (timer) clearInterval(timer) })
async function retry() { if (!selected.value) return; retrying.value = true; try { await api.retryProvision(selected.value.id); selected.value = null; await refresh(); ElMessage.success('重推任务已创建') } catch (e) { ElMessage.error((e as Error).message) } finally { retrying.value = false } }
function duration(ms: number) { return ms ? `${Math.round(ms / 1000)} 秒` : '—' }
</script>

<template>
  <PageHeader eyebrow="MALL PROVISIONING" title="供数监控" description="统一观察外部商场的数据推送、错误响应和重推记录。"><span class="soft-badge">{{ logs.length }} 条运行记录</span></PageHeader>
  <div class="metric-grid three"><div class="metric-card"><div class="metric-top"><span>运行记录</span></div><strong>{{ logs.length }}</strong><small>当前演示环境</small></div><div class="metric-card"><div class="metric-top"><span>推送成功</span></div><strong>{{ logs.filter(x => x.status === 'SUCCESS').length }}</strong><small>最近执行记录</small></div><div class="metric-card"><div class="metric-top"><span>失败告警</span></div><strong>{{ logs.filter(x => x.status === 'FAILED').length }}</strong><small>可查看响应并模拟重推</small></div></div>
  <div class="table-panel mt-18"><div class="table-toolbar"><div><h2>任务运行记录</h2><small>点击失败任务可查看报文摘要并模拟重推</small></div><div class="toolbar-inputs"><el-input v-model="query" clearable placeholder="搜索商场或任务" style="width:190px" /><el-select v-model="status" style="width:140px"><el-option label="全部状态" value="" /><el-option label="成功" value="SUCCESS" /><el-option label="失败" value="FAILED" /><el-option label="运行中" value="RUNNING" /></el-select></div></div><el-table :data="filtered" stripe empty-text="暂无符合条件的记录"><el-table-column label="目标商场" min-width="200"><template #default="{ row }"><strong>{{ row.mall_name }}</strong><small class="subcell">{{ row.mall_group }}</small></template></el-table-column><el-table-column prop="job_name" label="任务名称" min-width="145" /><el-table-column prop="biz_date" label="业务日期" width="120" /><el-table-column prop="protocol" label="协议" width="110" /><el-table-column label="状态" width="100"><template #default="{ row }"><StatusTag :status="row.status" /></template></el-table-column><el-table-column prop="rows_pushed" label="推送行数" width="110" /><el-table-column label="耗时" width="90"><template #default="{ row }">{{ duration(row.duration_ms) }}</template></el-table-column><el-table-column label="操作" width="110"><template #default="{ row }"><el-button link type="primary" @click="selected = row">查看详情 →</el-button></template></el-table-column></el-table><div class="table-note">当前供数数据为模拟记录，重推完成由后端演示任务驱动</div></div>
  <el-dialog :model-value="!!selected" :title="selected?.mall_name || '供数详情'" width="min(600px, 95vw)" @update:model-value="(value: boolean) => { if (!value) selected = null }"><el-descriptions :column="1" border><el-descriptions-item label="运行编号">{{ selected?.id }}</el-descriptions-item><el-descriptions-item label="商场 / 任务">{{ selected?.mall_name }} / {{ selected?.job_name }}</el-descriptions-item><el-descriptions-item label="业务日期">{{ selected?.biz_date }}</el-descriptions-item><el-descriptions-item label="运行状态"><StatusTag v-if="selected" :status="selected.status" /></el-descriptions-item><el-descriptions-item label="推送行数">{{ selected?.rows_pushed }}</el-descriptions-item><el-descriptions-item label="触发方式">{{ selected?.trigger_type === 'MANUAL' ? '人工重推' : '计划任务' }}</el-descriptions-item></el-descriptions><div v-if="selected?.req_payload_sample" class="response-title">请求样本（脱敏）</div><pre v-if="selected?.req_payload_sample" class="response-box">{{ selected.req_payload_sample }}</pre><div class="response-title">目标系统响应摘要</div><pre class="response-box">{{ selected?.resp_body || selected?.error_msg || selected?.response_summary || '任务仍在运行中' }}</pre><template #footer><el-button @click="selected = null">关闭</el-button><el-button v-if="selected?.status === 'FAILED'" type="primary" :loading="retrying" @click="retry">模拟重推</el-button></template></el-dialog>
</template>

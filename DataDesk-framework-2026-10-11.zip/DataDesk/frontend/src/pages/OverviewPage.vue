<script setup lang="ts">
import { onMounted, ref } from 'vue'
import { useRouter } from 'vue-router'
import { ArrowRight, DataAnalysis, Download, Files, Warning } from '@element-plus/icons-vue'
import { api } from '../api'
import PageHeader from '../components/PageHeader.vue'
import StatusTag from '../components/StatusTag.vue'
import type { Overview } from '../types'

const router = useRouter()
const data = ref<Overview | null>(null)
const error = ref('')
onMounted(async () => { try { data.value = await api.overview() } catch (e) { error.value = (e as Error).message } })
const dateLabel = new Intl.DateTimeFormat('zh-CN', { dateStyle: 'long' }).format(new Date())
</script>

<template>
  <PageHeader eyebrow="OPERATIONS OVERVIEW" title="早上好，数据管理员" :description="`${dateLabel} · 数据服务和分发任务一切尽在掌握`">
    <el-button @click="router.push('/provision')">查看异常</el-button><el-button type="primary" @click="router.push('/studio')">发起取数</el-button>
  </PageHeader>
  <el-alert v-if="error" :title="error" type="error" show-icon :closable="false" class="mb-18" />
  <section class="hero"><div><div class="hero-kicker">YOUR DATA WORKSPACE</div><h2>数据有序流转，问题一眼可见。</h2><p>统一查看报表资产、自助导出和商场供数状态。从发现异常到重新推送，都在同一个工作台完成。</p></div><div class="hero-actions"><el-button @click="router.push('/studio')">开始取数 <el-icon><ArrowRight /></el-icon></el-button><el-button plain @click="router.push('/reports')">浏览报表</el-button></div></section>
  <div class="metric-grid">
    <div class="metric-card"><div class="metric-top"><span>供数记录</span><el-icon class="metric-icon teal"><Files /></el-icon></div><strong>{{ data?.planned ?? '—' }}</strong><small>当前演示数据</small></div>
    <div class="metric-card"><div class="metric-top"><span>推送成功率</span><el-icon class="metric-icon blue"><DataAnalysis /></el-icon></div><strong>{{ data ? `${data.success_rate}%` : '—' }}</strong><small>{{ data?.success ?? 0 }} 个任务成功完成</small></div>
    <div class="metric-card"><div class="metric-top"><span>待处理异常</span><el-icon class="metric-icon orange"><Warning /></el-icon></div><strong>{{ data?.failed ?? '—' }}</strong><small>可进入监控查看响应</small></div>
    <div class="metric-card"><div class="metric-top"><span>我的导出任务</span><el-icon class="metric-icon purple"><Download /></el-icon></div><strong>{{ data?.my_exports ?? '—' }}</strong><small>{{ data?.active_exports ?? 0 }} 个排队或处理中</small></div>
  </div>
  <div class="section-heading"><div><h2>快捷入口</h2><small>常用工作一步直达</small></div></div>
  <div class="quick-grid"><button class="quick-card" @click="router.push('/reports')"><span class="quick-icon"><el-icon><DataAnalysis /></el-icon></span><span><strong>浏览经营报表</strong><small>发现已授权的 Power BI 报表</small></span><el-icon><ArrowRight /></el-icon></button><button class="quick-card" @click="router.push('/studio')"><span class="quick-icon"><el-icon><Files /></el-icon></span><span><strong>创建导出任务</strong><small>按业务主题筛选和预览数据</small></span><el-icon><ArrowRight /></el-icon></button><button class="quick-card" @click="router.push('/provision')"><span class="quick-icon"><el-icon><Warning /></el-icon></span><span><strong>排查供数异常</strong><small>查看响应摘要并发起重推</small></span><el-icon><ArrowRight /></el-icon></button></div>
  <div class="section-heading"><div><h2>最近供数记录</h2><small>按执行时间排序</small></div><el-button link type="primary" @click="router.push('/provision')">进入供数监控 →</el-button></div>
  <div class="table-panel"><el-table :data="data?.recent_logs || []" stripe><el-table-column prop="mall_name" label="目标商场" min-width="190" /><el-table-column prop="job_name" label="任务名称" min-width="130" /><el-table-column prop="biz_date" label="业务日期" width="130" /><el-table-column prop="protocol" label="协议" width="110" /><el-table-column label="状态" width="105"><template #default="{ row }"><StatusTag :status="row.status" /></template></el-table-column><el-table-column prop="rows_pushed" label="推送行数" width="110" /><el-table-column label="操作" width="110"><template #default><el-button link type="primary" @click="router.push('/provision')">查看详情 →</el-button></template></el-table-column></el-table></div>
</template>

<script setup lang="ts">
import { computed, onMounted, onUnmounted, ref } from 'vue'
import { ElMessage } from 'element-plus'
import { useRouter } from 'vue-router'
import { api } from '../api'
import PageHeader from '../components/PageHeader.vue'
import StatusTag from '../components/StatusTag.vue'
import type { ExportTask } from '../types'

const router = useRouter()
const tasks = ref<ExportTask[]>([])
const status = ref('')
const filtered = computed(() => tasks.value.filter(t => !status.value || t.status === status.value))
let timer: ReturnType<typeof setInterval> | undefined
async function refresh() { try { tasks.value = await api.tasks() } catch (e) { ElMessage.error((e as Error).message) } }
onMounted(() => { refresh(); timer = setInterval(refresh, 5000) })
onUnmounted(() => { if (timer) clearInterval(timer) })
function size(bytes: number | null) { if (!bytes) return '—'; return bytes < 1024 ? `${bytes} B` : bytes < 1048576 ? `${(bytes/1024).toFixed(1)} KB` : `${(bytes/1048576).toFixed(1)} MB` }
function stamp(value: string) { return new Date(`${value}Z`).toLocaleString('zh-CN') }
function download(task: ExportTask) { window.location.href = api.downloadUrl(task) }
</script>

<template>
  <PageHeader eyebrow="EXPORT CENTER" title="下载中心" description="查看导出任务的排队、执行和交付状态。"><el-button type="primary" @click="router.push('/studio')">创建新任务</el-button></PageHeader>
  <div class="metric-grid three"><div class="metric-card"><div class="metric-top"><span>全部任务</span></div><strong>{{ tasks.length }}</strong><small>近 100 条个人任务</small></div><div class="metric-card"><div class="metric-top"><span>正在处理</span></div><strong>{{ tasks.filter(t => ['PENDING', 'RUNNING'].includes(t.status)).length }}</strong><small>排队或执行中</small></div><div class="metric-card"><div class="metric-top"><span>可下载</span></div><strong>{{ tasks.filter(t => t.status === 'SUCCESS').length }}</strong><small>文件保留 72 小时</small></div></div>
  <div class="table-panel mt-18"><div class="table-toolbar"><div><h2>我的导出记录</h2><small>Worker 完成任务后可下载 CSV.GZ 文件</small></div><el-select v-model="status" style="width:150px"><el-option label="全部状态" value="" /><el-option label="成功" value="SUCCESS" /><el-option label="运行中" value="RUNNING" /><el-option label="排队中" value="PENDING" /><el-option label="失败" value="FAILED" /></el-select></div><el-table :data="filtered" stripe empty-text="暂无符合条件的任务"><el-table-column label="任务编号" min-width="125"><template #default="{ row }"><strong>{{ row.id.slice(0, 8) }}</strong></template></el-table-column><el-table-column prop="template_code" label="数据主题" min-width="170" /><el-table-column label="创建时间" min-width="170"><template #default="{ row }">{{ stamp(row.created_at) }}</template></el-table-column><el-table-column label="状态" width="100"><template #default="{ row }"><StatusTag :status="row.status" /></template></el-table-column><el-table-column label="数据行数" width="110"><template #default="{ row }">{{ row.row_count ?? '—' }}</template></el-table-column><el-table-column label="文件大小" width="110"><template #default="{ row }">{{ size(row.file_size_bytes) }}</template></el-table-column><el-table-column label="操作" width="120"><template #default="{ row }"><el-button v-if="row.status === 'SUCCESS'" link type="primary" @click="download(row)">下载文件 ↓</el-button><span v-else-if="row.status === 'FAILED'" class="error-text" :title="row.error_msg">执行失败</span><span v-else class="muted">等待处理</span></template></el-table-column></el-table><div class="table-note">文件将在创建 72 小时后过期 · 页面每 5 秒更新一次状态</div></div>
</template>

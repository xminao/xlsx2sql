<script setup lang="ts">
import { computed, onMounted, onUnmounted, ref } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { Bell, DataAnalysis, Download, Files, Grid, Menu, Operation, Tickets } from '@element-plus/icons-vue'
import { api } from './api'
import { pageNames } from './router'
import StatusTag from './components/StatusTag.vue'
import type { ExportTask } from './types'

const route = useRoute()
const router = useRouter()
const drawer = ref(false)
const mobileMenu = ref(false)
const tasks = ref<ExportTask[]>([])
const activeCount = computed(() => tasks.value.filter(t => ['PENDING', 'RUNNING'].includes(t.status)).length)
let timer: ReturnType<typeof setInterval> | undefined

async function refreshTasks() { try { tasks.value = await api.tasks() } catch { /* page shows its own error */ } }
onMounted(() => { refreshTasks(); timer = setInterval(refreshTasks, 5000) })
onUnmounted(() => { if (timer) clearInterval(timer) })
function go(path: string) { mobileMenu.value = false; drawer.value = false; router.push(path) }
function download(task: ExportTask) { window.location.href = api.downloadUrl(task) }
function formatTime(value: string) { return new Date(value + (value.endsWith('Z') ? '' : 'Z')).toLocaleString('zh-CN', { month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit' }) }
</script>

<template>
  <div class="app-shell">
    <div v-if="mobileMenu" class="mobile-shade" @click="mobileMenu = false" />
    <aside class="sidebar" :class="{ open: mobileMenu }">
      <div class="brand"><div class="brand-mark"><el-icon :size="23"><Operation /></el-icon></div><div><div class="brand-name">DataDesk</div><div class="brand-sub">DATA OPERATIONS</div></div></div>
      <div class="nav-caption">WORKSPACE · 工作台</div>
      <button class="nav-item" :class="{ active: route.path === '/' }" @click="go('/')"><el-icon><Grid /></el-icon><span>总览</span></button>
      <button class="nav-item" :class="{ active: route.path === '/reports' }" @click="go('/reports')"><el-icon><DataAnalysis /></el-icon><span>报表中心</span></button>
      <button class="nav-item" :class="{ active: route.path === '/studio' }" @click="go('/studio')"><el-icon><Files /></el-icon><span>自助取数</span></button>
      <button class="nav-item" :class="{ active: route.path === '/downloads' }" @click="go('/downloads')"><el-icon><Download /></el-icon><span>下载中心</span><b v-if="activeCount" class="nav-count">{{ activeCount }}</b></button>
      <div class="nav-caption">OPERATIONS · 运营管理</div>
      <button class="nav-item" :class="{ active: route.path === '/provision' }" @click="go('/provision')"><el-icon><Tickets /></el-icon><span>供数监控</span></button>
      <button class="nav-item" :class="{ active: route.path === '/assets' }" @click="go('/assets')"><el-icon><Operation /></el-icon><span>数据资产</span></button>
      <div class="sidebar-bottom"><div class="system-status"><i class="pulse" /> API 与 Worker 分离运行</div><div class="sidebar-meta">DataDesk Console · Framework v0.1</div></div>
    </aside>
    <div class="main-area">
      <header class="topbar"><div class="breadcrumb"><el-button class="mobile-toggle" text :icon="Menu" @click="mobileMenu = true" />DataDesk <span>/</span> <strong>{{ pageNames[route.path] || '总览' }}</strong></div><div class="top-actions"><el-tooltip content="查看下载任务"><el-badge :value="activeCount" :hidden="!activeCount"><el-button circle :icon="Download" @click="drawer = true" /></el-badge></el-tooltip><div class="avatar">DL</div><div class="user-info"><strong>数据管理员</strong><small>演示账号</small></div></div></header>
      <main class="content"><router-view /></main>
    </div>
    <el-drawer v-model="drawer" title="下载任务" size="min(420px, 100%)">
      <div v-if="tasks.length" class="drawer-task-list"><div v-for="task in tasks" :key="task.id" class="drawer-task"><div class="flex-between"><strong>{{ task.template_code }}</strong><StatusTag :status="task.status" /></div><small>{{ task.id.slice(0, 8) }} · {{ formatTime(task.created_at) }}</small><div class="flex-between task-foot"><span>{{ task.status === 'SUCCESS' ? `${task.row_count || 0} 行` : task.status === 'PENDING' ? '等待 Worker 认领' : '处理中' }}</span><el-button v-if="task.status === 'SUCCESS'" size="small" type="primary" plain @click="download(task)">下载</el-button></div></div></div>
      <el-empty v-else description="暂无导出任务" />
      <el-button style="width:100%;margin-top:16px" @click="go('/downloads')">查看全部任务</el-button>
    </el-drawer>
  </div>
</template>

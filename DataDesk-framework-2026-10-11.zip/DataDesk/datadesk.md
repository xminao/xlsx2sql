# DataDesk 统一数据服务与调度平台架构设计方案

---

## 1. 系统概述与设计哲学

### 1.1 系统定位
DataDesk 是面向企业内部构建的轻量级、插件化、高可用统一数据服务中枢（Data Service & Operations Hub）。系统聚焦于三大核心业务场景：
* **报表中心**：全公司商业智能报表的统一跳板门户，收拢并跳转/嵌入微软 Power BI Service。
* **自助取数**：基于元数据驱动的动态筛选表单、秒级采样预览与防爆内存的异步流式出数中枢。
* **供数管理**：面向万达、华润、龙湖等外部商场系统的 B2B 外部数据分发 Job 调度、状态监控、错误穿透与重推控制台。

### 1.2 核心架构原则
* **控制面与执行面分离（Control Plane Only）**：平台核心服务（FastAPI）定位为纯粹的状态管理与元数据网关，不维护下游具体业务逻辑，不主动建立向外的长连接调用。
* **单向认领模式（Pull / Claim Pattern）**：导数 Worker 采用主动轮询拉取任务，消除平台对执行节点的网络探测与 IP/端口绑定负担，具备天然的弹性水平扩展能力。
* **零 OOM 内存防线（Zero-OOM Pipeline）**：从数仓提取到文件压缩全程采用服务端游标与流式管道化写入，执行内存消耗严格限定在常数级（< 50MB）。
* **元数据驱动一切（Schema-Driven）**：导出表单与查询拼装完全由配置驱动，新增导出主题无需修改任何前端与后端代码。
* **原生轻量部署**：完全兼容 Windows Server 原生环境，免除 Docker / WSL 依赖，实现单机双服务自愈托管。

---

## 2. 总体逻辑架构设计

系统采用“四层解耦”架构，涵盖展现层、控制面、执行面及底层数据基础设施：

```
┌────────────────────────────────────────────────────────────────────────┐
│                        展现层 (Presentation Layer)                     │
│    Geeker-Admin (Vue3 + TS + Element Plus) 静态打包托管于 API 根路径    │
│  • 报告中心 (PBI 导航)   • 取数工作台 (动态表单)   • 全局下载中心 (常驻抽屉) │
│  • 供数管理 (Job 监控)   • 资产管理 (指标/Schema)   • 排错与重推交互控制台   │
└───────────────────────────────────┬────────────────────────────────────┘
                                    │ HTTP RESTful / JWT 鉴权
┌───────────────────────────────────▼────────────────────────────────────┐
│                       控制面 (Control Plane API)                       │
│    Python FastAPI 单一常驻服务                                          │
│  • 静态资源与文件下载挂载 (/、/downloads)                                │
│  • 动态表单元数据提供 (/api/v1/export-schemas)                          │
│  • 导出任务状态机网关 (/api/v1/exports/create, claim, complete)         │
│  • 供数状态汇报网关 (/api/v1/provision/jobs/start, finish, retry)       │
└──────────────────────┬──────────────────────────┬──────────────────────┘
                       │ 读写元数据                │ 读写状态与日志
┌──────────────────────▼──────────────────────────▼──────────────────────┐
│                    数据与元数据存储 (Metadata Store)                   │
│    PostgreSQL 业务实例                                                 │
│  • export_schemas (表单元数据)     • export_tasks (无锁任务队列)       │
│  • mall_configs (商场凭据)         • provision_logs (审计日志)         │
└─────────────────────────────────────────────────▲──────────────────────┘
                                                  │
                       ┌──────────────────────────┴──────────────────────────┐
                       │                                                     │
┌──────────────────────┴──────────────────────┐  ┌───────────────────────────┴────────────────┐
│         执行面：导出 Worker 守护进程        │  │       执行面：商场供数 Job 插件 (SDK)       │
│  • 任务原子抢占 (FOR UPDATE SKIP LOCKED)    │  │  • 定时触发器 (Windows 计划任务/Cron)      │
│  • 白名单校验与参数化 SQL 拼装 (QueryBuilder)│  │  • 任务启动与凭据装载 (POST /start)         │
│  • 服务端命名游标分批抽取 (Fetchmany 10000) │  │  • 数仓抽取 -> 外部接口推送 (万达/华润)    │
│  • 本地管道流式压缩 (.csv.gz)               │  │  • 零数据拦截防护与报文采样截断           │
│  • 任务终态与文件元数据回传 (POST /complete)│  │  • 终态与异常堆栈回传 (POST /finish)       │
└──────────────────────┬──────────────────────┘  └───────────────────────────┬────────────────┘
                       │ 只读流式查询                                        │ 业务数据抽取
┌──────────────────────▼─────────────────────────────────────────────────────▼────────────────┐
│                       数据底座 (Data Warehouse Layer)                                       │
│    PostgreSQL 数仓只读副本 (千万级明细) + 本地 Parquet 列存 (DuckDB 秒级抽样加速)           │
└─────────────────────────────────────────────────────────────────────────────────────────────┘
```

---

## 3. 核心业务模块功能设计

### 3.1 报告中心模块 (`/reports`)
* **核心定位**：统一管理并重定向全公司分散的 Power BI 报表资源。
* **展示结构**：按业务板块（零售营运、供应链、用户增长、财务核算）组织卡片流。
* **访问机制**：
  * 默认模式：通过外部新标签页安全跳转至 Power BI Service。
  * 嵌入模式：通过平台内部 Iframe 组件实现免切屏浏览。
* **权限策略**：根据用户登录的角色标识（RBAC），由后端接口动态返回可见报表白名单，无权报表对前台完全不可见。

### 3.2 自助取数与导出中心模块 (`/export`)
* **取数工作台 (`/export/studio`)**：
  * **主题选择**：下拉选择业务模型，前端根据响应的 Schema 动态构建表单。
  * **按需勾选字段**：区分业务维度与度量，敏感字段（如成本金额）根据权限自动置灰禁用。
  * **前置数据预览**：点击“查询预览”时，后端基于 DuckDB 或 PG 带限制采样返回前 50 条脱敏数据，用于核对口径，消除盲导现象。
  * **异步导出下发**：用户选定格式与命名后点击“提交”，请求仅负责任务登记，毫秒级响应 Task ID。
* **全局下载中心抽屉 (常驻 Header 右侧)**：
  * 全局悬浮抽屉交互，实时展示任务排队、执行中、成功与失败状态。
  * 动态轮询机制：存在活动任务（`PENDING` / `RUNNING`）时启动 3 秒轮询，全部归于终态后自动静默停止。
  * 产物交付：生成成功展示文件体积与行数，提供单键下载链接。

### 3.3 供数调度与监控模块 (`/mall-provision`)
* **态势看板**：汇总今日计划推送商场总数、成功数、失败报警数、累计分发流水条数。
* **任务监控控制台 (`ProTable`)**：按业务日期展示所有商场推送状态、执行耗时、分发记录数及商场协议类型。
* **排错分析抽屉**：
  * 状态异常（`FAILED`）时提供明细查看，展示脱敏后的请求 Payload 摘要。
  * 穿透展示目标商场网关的原始返回报文（如 HTTP 401 凭证失效、业务代码校验未通过）。
* **手动重推机制**：针对因网络抖动或凭据过期失败的记录，支持在控制台点击“一键重推”，由后端派发独立的补偿执行进程。

---

## 4. 关键流程与通信机制设计

### 4.1 自助导出：认领任务（Claim/Pull）与流式写入时序

```
[前端 Geeker-Admin]       [DataDesk API]          [PG 任务表]         [Export Worker]      [PG 数仓只读库]
        │                        │                     │                     │                   │
        │ 1. 提交取数参数 (DSL)  │                     │                     │                   │
        ├───────────────────────>│                     │                     │                   │
        │                        │ 2. 插入任务 PENDING │                     │                   │
        │                        ├────────────────────>│                     │                   │
        │ 3. 毫秒级返回 Task ID  │                     │                     │                   │
        │<───────────────────────┤                     │                     │                   │
        │                        │                     │                     │                   │
        │                        │                     │ 4. 周期抢单轮询     │                   │
        │                        │ 5. 原子锁行抢占     │<────────────────────┤                   │
        │                        │   (SKIP LOCKED)     │                     │                   │
        │                        ├────────────────────>│                     │                   │
        │                        │ 6. 返回抢占的任务   │                     │                   │
        │                        │──────────────────────────────────────────>│                   │
        │                        │                     │                     │ 7. 开启命名游标   │
        │                        │                     │                     ├──────────────────>│
        │                        │                     │                     │ 8. 分批拉取数据   │
        │                        │                     │                     │<──────────────────┤
        │                        │                     │                     │ (边读边写 .csv.gz)│
        │                        │                     │                     │                   │
        │                        │ 9. POST /complete   │                     │                   │
        │                        │<──────────────────────────────────────────┤                   │
        │                        │ 10. 更新 SUCCESS    │                     │                   │
        │                        ├────────────────────>│                     │                   │
        │ 11. 前端轮询获取结果   │                     │                     │                   │
        ├───────────────────────>│                     │                     │                   │
        │ 12. 返回文件下载地址   │                     │                     │                   │
        │<───────────────────────┤                     │                     │                   │
```

### 4.2 结构化查询协议 (Filter DSL) 规范
前端不直接参与 SQL 构建，所有筛选条件统一序列化为结构化 DSL：
* **结构约定**：
  * `template_code`：目标业务模型标识符。
  * `selected_columns`：用户勾选的输出列白名单数组。
  * `filters`：条件对象数组，单项包含 `field`（字段名）、`op`（操作符代码）、`val`（筛选值）。
* **操作符支持集**：
  * 等值匹配：`eq` (`=`), `neq` (`!=`)
  * 范围与比较：`gt` (`>`), `gte` (`>=`), `lt` (`<`), `lte` (`<=`), `between` (`BETWEEN`)
  * 集合与模糊：`in` (`ANY`), `like` (`ILIKE`)
* **安全翻译准则 (QueryBuilder)**：
  * 严格比对 Schema 字段白名单，非白名单字段直接剔除。
  * 动态参数完全走驱动级占位符（`%s` / `%(key)s`）绑定，严禁使用字符串拼接值。
  * 强制注入安全行数上限（`LIMIT` 拦截）。

### 4.3 供数任务：SDK 插件化生命周期与状态上报
商场供数脚本作为通用任务插件运行，其标准生命周期包含四个阶段：
1. **启动与凭据装载**：脚本唤醒后向 DataDesk 发起登记请求，DataDesk 返回本次运行的 `run_id` 及对应商场保存在系统中的鉴权凭据（AppId / Secret）。
2. **数仓数据提取与零行防御**：脚本基于数仓抽取指定业务日期的数据。若发现提取条数为 0，强制触发异常终止，严防向上游空推数据导致合规处罚。
3. **外部推送与样本保留**：脚本将数据打包推送到商场 API 或 SFTP 服务器，期间截取前 3 条作为样本存储在上下文中，同时截获商场的原始 Response Body。
4. **终态回报**：脚本成功或遇到异常时，由 SDK 负责向 DataDesk API 发送最终回调，更新运行状态、耗时、实际推送条数与报错堆栈。

---

## 5. 数据模型与元数据设计

系统在 PostgreSQL 中维护 5 张核心元数据与状态表：

### 5.1 导出模型 Schema 配置表 (`export_schemas`)
管理所有导数业务主题的元数据定义。
* `template_code` (VARCHAR, PK)：模型唯一标识代码（如 `mall_sales_di`）。
* `template_name` (VARCHAR)：面向业务的显示名称。
* `category` (VARCHAR)：业务分类域。
* `base_table` (VARCHAR)：底层的数仓事实表或预聚合视图名。
* `columns_config` (JSONB)：允许导出的字段配置（包含字段名、别名、默认勾选状态、所需查看角色）。
* `filter_config` (JSONB)：前端表单控件配置（控件类型：`date_range`, `select_multiple`, `number_range`；数据来源；是否必填）。
* `max_limit` (INT)：单次导出最大安全截断行数。
* `is_active` (BOOLEAN)：模板启用开关。

### 5.2 异步导出任务表 (`export_tasks`)
承载异步导出的无锁任务队列与产物元数据。
* `task_id` (UUID, PK)：任务唯一追踪号。
* `user_id` (VARCHAR)：发起人工号/账号。
* `export_type` (VARCHAR, FK)：关联的模板编码。
* `filters` (JSONB)：前端提交的 Filter DSL 完整快照。
* `status` (ENUM)：任务生命周期状态（`PENDING`, `RUNNING`, `SUCCESS`, `FAILED`, `CANCELLED`）。
* `file_url` (TEXT)：生成后的静态文件下载路径。
* `file_size_bytes` (BIGINT)：产物体积字节数。
* `row_count` (BIGINT)：实际抽取出的明细行数。
* `error_msg` (TEXT)：失败堆栈摘要。
* `created_at` / `started_at` / `completed_at` (TIMESTAMPTZ)：各节点时间戳。
* `expires_at` (TIMESTAMPTZ)：文件失效时间（默认创建后 72 小时）。

### 5.3 外部商场体系配置表 (`mall_configs`)
管理第三方商场的通讯协议与加密认证凭证。
* `mall_code` (VARCHAR, PK)：商场唯一编码。
* `mall_name` (VARCHAR)：商场名称。
* `mall_group` (VARCHAR)：所属商业集团（如 `WANDA`, `MIXC`, `LONGFOR`）。
* `protocol` (VARCHAR)：通信协议（`HTTP_API`, `SFTP`, `DB_DIRECT`）。
* `endpoint_url` (TEXT)：接口基准地址或 SFTP 连接主机。
* `auth_credentials` (JSONB)：加密存储的密钥对（如 AppId, AppSecret, SFTP 私钥）。
* `is_active` (BOOLEAN)：配置启用状态。

### 5.4 供数 Job 注册表 (`provision_jobs`)
定义外部供数业务的调度编排规范。
* `job_code` (VARCHAR, PK)：任务代码（如 `wanda_daily_sales`）。
* `job_name` (VARCHAR)：任务业务名称。
* `mall_group` (VARCHAR)：适用的商场体系。
* `cron_expr` (VARCHAR)：标准 Cron 调度表达式。
* `handler_module` (VARCHAR)：执行该业务的对应 Python 模块路径。
* `timeout_seconds` (INT)：全局超时控制阈值。
* `is_active` (BOOLEAN)：调度状态。

### 5.5 供数执行审计与排错日志表 (`provision_logs`)
记录所有供数运行细节，支持追溯与重推。
* `run_id` (UUID, PK)：运行实例唯一标识。
* `job_code` (VARCHAR, FK)：关联的任务编码。
* `mall_code` (VARCHAR, FK)：关联的商场编码。
* `biz_date` (DATE)：处理的数据业务日期。
* `status` (VARCHAR)：执行状态（`RUNNING`, `SUCCESS`, `FAILED`）。
* `rows_pushed` (INT)：本次实际发送成功的明细条数。
* `duration_ms` (INT)：总耗时（毫秒）。
* `req_payload_sample` (TEXT)：发送报文采样切片（保留前 2KB）。
* `resp_body` (TEXT)：接收端返回的原始报文（保留前 2KB）。
* `error_msg` (TEXT)：系统异常堆栈。
* `trigger_type` (VARCHAR)：触发源（`AUTO` 自动定时调度 / `MANUAL` 人工控制台重推）。
* `triggered_by` (VARCHAR)：触发人标识。

---

## 6. API 契约与通信接口设计规范

所有接口统一以 JSON 承载，受统一 JWT Bearer Token 鉴权保护。

### 6.1 导出中心接口
| 请求方式 | 路由端点 | 描述 | 请求核心参数 | 成功返回核心结构 |
| :--- | :--- | :--- | :--- | :--- |
| `GET` | `/api/v1/export-schemas` | 获取可用导出主题列表 | 无 | 模板编码、名称、分类列表 |
| `GET` | `/api/v1/export-schemas/{code}` | 获取指定主题的完整 Schema | `code` (路径参数) | 字段白名单、筛选器配置规则 |
| `POST` | `/api/v1/exports/create` | 提交异步导出任务 | `template_code`, `filters` (DSL) | `{ "task_id": "...", "status": "PENDING" }` |
| `POST` | `/api/v1/exports/claim` | Worker 原子抢占任务 | 无 (内部服务级 Token 鉴权) | `{ "task": { task_id, export_type, filters } }` |
| `POST` | `/api/v1/exports/{id}/complete` | Worker 汇报任务终态 | `status`, `file_url`, `row_count`, `error_msg` | `{ "acknowledged": true }` |
| `GET` | `/api/v1/exports/my-tasks` | 查询个人下载中心任务列表 | 分页参数、状态过滤 | 任务对象数组（含状态、进度、文件信息） |

### 6.2 供数管理接口
| 请求方式 | 路由端点 | 描述 | 请求核心参数 | 成功返回核心结构 |
| :--- | :--- | :--- | :--- | :--- |
| `GET` | `/api/v1/provision/logs` | 供数监控列表查询 | `biz_date`, `mall_code`, `status` | 包含日志详情、报文采样的记录集 |
| `POST` | `/api/v1/provision/jobs/start` | 供数 Job 初始化上报 | `job_code`, `mall_code`, `biz_date` | `{ "run_id": "...", "mall_config": { ... } }` |
| `POST` | `/api/v1/provision/jobs/finish` | 供数 Job 执行终态回报 | `run_id`, `status`, `rows`, `sample`, `resp` | `{ "success": true }` |
| `POST` | `/api/v1/provision/jobs/retry` | 控制台触发手动重推 | `job_code`, `mall_code`, `biz_date` | 异步下发子进程指令，返回新排队的 `run_id` |

---

## 7. 生产部署与系统安全防护架构

### 7.1 Windows Server 生产环境部署拓扑
* **单一运行目录规划**：所有服务及产物集中在指定工作区（如 `D:\DataDesk\`）：
  * `D:\DataDesk\backend\`：FastAPI 应用主体及打包后的前端静态资源目录（`static/`）。
  * `D:\DataDesk\worker\`：通用 Export Worker 守护程序与 QueryBuilder 模块。
  * `D:\DataDesk\exports\`：流式写盘生成的压缩文件产物存储目录。
  * `D:\DataDesk\logs\`：系统标准输出与错误日志输出目录。
* **原生服务注册（NSSM 方案）**：
  * **主服务 (`DataDesk-API`)**：托管 Uvicorn 执行环境，监听 80 端口，开机自启并配置崩溃自动拉起。
  * **执行服务 (`DataDesk-Worker`)**：托管 Python Worker 轮询进程，独立于主 Web 服务运行。

### 7.2 生产级安全防护与熔断机制
* **时间范围强制拦截（No-Full-Scan Guard）**：对于明细类宽表模型，在 Schema 层面标记时间筛选器为 `required: true`。若缺少日期范围，控制面直接拦截请求，禁止向任务表入库。
* **数据库级查询熔断**：Worker 与数仓建立的数据库连接会话上，强制配置 `statement_timeout = 300000`（5 分钟）。任何未命中分区或超大复杂联合查询在超时后强制被数仓切断，避免锁表与计算资源挤占。
* **空数据防推屏障（Zero-Row Provisioning Guard）**：商场推送逻辑中硬性规定条数下限，若抽取条数为 0 则阻断执行并转为报警状态，禁止推空包给外部合作方。
* **文件存储生命周期管理（TTL 清理）**：
  * 任务表中基于 `expires_at` 字段标记失效时间。
  * 部署每日轻量清理计划，针对创建时间超过 72 小时的磁盘物理文件执行删除操作，释放服务器磁盘空间。